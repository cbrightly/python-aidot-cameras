package com.tutk.IOTC;

import android.os.AsyncTask;
import android.util.Log;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TutkManager {
   private static final String TAG = "TutkManager";
   private TutkListener listener;
   private int sessionId;
   private int connectId;
   private int channelId;
   private int talkChannelId;
   private int talkServerId;
   private boolean videoLoop;
   private boolean audioLoop;
   ExecutorService newCachedThreadPool;
   private static final int VIDEO_BUF_SIZE = 100000;
   private static final int FRAME_INFO_SIZE = 16;
   private byte[] videoBuffer;
   private int[] outBufSize;
   private int[] outFrameSize;
   private byte[] frameInfo;
   private int[] outFrmInfoBufSize;
   private int[] frameNumber;
   private static final int AUDIO_BUF_SIZE = 1024;
   private byte[] audioBuffer;
   private byte[] adutioFrameInfo;

   private TutkManager() {
      this.sessionId = -1;
      this.connectId = -1;
      this.channelId = -1;
      this.talkChannelId = -1;
      this.talkServerId = -1;
      this.videoLoop = false;
      this.audioLoop = false;
      this.newCachedThreadPool = Executors.newCachedThreadPool();
      this.videoBuffer = new byte[100000];
      this.outBufSize = new int[1];
      this.outFrameSize = new int[1];
      this.frameInfo = new byte[16];
      this.outFrmInfoBufSize = new int[1];
      this.frameNumber = new int[1];
      this.audioBuffer = new byte[1024];
   }

   public static TutkManager getInstance() {
      return TutkManager.SingletonHolder.instance;
   }

   public void setListener(TutkListener listener) {
      this.listener = listener;
   }

   public int init() {
      int ret = IOTCAPIs.IOTC_Initialize2(0);
      if (ret == 0) {
         IOTCAPIs.IOTC_Set_Max_Session_Number(10);
         AVAPIs.avInitialize(32);
      }

      Log.e("TutkManager", "init: " + ret);
      return ret;
   }

   public void unInit() {
      AVAPIs.avDeInitialize();
      IOTCAPIs.IOTC_DeInitialize();
   }

   public void startGetStream(String uid, String account, String pwd) {
      TutkManager.TutkParam param = new TutkManager.TutkParam(uid, account, pwd);
      (new TutkManager.ClientStartTask()).execute(new TutkManager.TutkParam[]{param});
   }

   public void stopStream() {
      this.videoLoop = false;
      this.audioLoop = false;
      this.listener = null;
      (new TutkManager.ReleaseTask()).executeOnExecutor(this.newCachedThreadPool, new Void[0]);
   }

   private int connect(String uid) {
      this.sessionId = IOTCAPIs.IOTC_Get_SessionID();
      Log.e("TutkManager", "IOTC_Get_SessionID:" + this.sessionId);
      if (this.sessionId >= 0) {
         int ret = IOTCAPIs.IOTC_Connect_ByUID_Parallel(uid, this.sessionId);
         Log.e("TutkManager", uid + " IOTC_Connect_ByUID_Parallel:" + ret);
         return ret;
      } else {
         return this.sessionId;
      }
   }

   private int clientStart(String uid, String account, String pwd) {
      int nSID = this.connect(uid);
      if (nSID >= 0) {
         this.connectId = nSID;
         int[] srvType = new int[1];
         int[] nSend = new int[1];
         int avIndex = AVAPIs.avClientStart2(nSID, account, pwd, 2000, srvType, 0, nSend);
         return avIndex;
      } else {
         return nSID;
      }
   }

   private boolean startIpcamStream(int avIndex) {
      int ret = AVAPIs.avSendIOCtrl(avIndex, 255, new byte[2], 2);
      if (ret < 0) {
         System.out.printf("start_ipcam_stream failed[%d]\n", ret);
         return false;
      } else {
         int IOTYPE_USER_IPCAM_START = 511;
         ret = AVAPIs.avSendIOCtrl(avIndex, IOTYPE_USER_IPCAM_START, new byte[8], 8);
         if (ret < 0) {
            System.out.printf("start_ipcam_stream failed[%d]\n", ret);
            return false;
         } else {
            int IOTYPE_USER_IPCAM_AUDIOSTART = 768;
            ret = AVAPIs.avSendIOCtrl(avIndex, IOTYPE_USER_IPCAM_AUDIOSTART, new byte[8], 8);
            if (ret < 0) {
               System.out.printf("start_ipcam_stream failed[%d]\n", ret);
               return false;
            } else {
               return true;
            }
         }
      }
   }

   private void getVideoStream(int avIndex) {
      int ret = AVAPIs.avRecvFrameData2(avIndex, this.videoBuffer, 100000, this.outBufSize, this.outFrameSize, this.frameInfo, 16, this.outFrmInfoBufSize, this.frameNumber);
      if (this.listener != null) {
         if (ret >= 0) {
            byte[] tbs = new byte[4];
            System.arraycopy(this.frameInfo, 12, tbs, 0, 4);
            this.listener.OnreceiveVideoData(ret, (long)this.byte2int(tbs), this.videoBuffer);
         } else {
            this.listener.OnreceiveVideoData(ret, 0L, (byte[])null);
         }
      }

   }

   private void getAudioStream(int avIndex) {
      int result = AVAPIs.avCheckAudioBuf(avIndex);
      if (result >= 0 && result < 3) {
         try {
            Thread.sleep(120L);
         } catch (InterruptedException var5) {
            var5.printStackTrace();
         }
      }

      int ret = AVAPIs.avRecvAudioData(avIndex, this.audioBuffer, 1024, this.frameInfo, 16, this.frameNumber);
      if (this.listener != null) {
         if (ret >= 0) {
            byte[] tbs = new byte[4];
            System.arraycopy(this.frameInfo, 12, tbs, 0, 4);
            this.listener.OnReceiveAudioData(ret, (long)this.byte2int(tbs), this.audioBuffer);
         } else {
            this.listener.OnReceiveAudioData(ret, 0L, (byte[])null);
         }
      }

   }

   private void stop() {
      AVAPIs.avClientExit(this.sessionId, this.channelId);
      if (this.channelId > -1) {
         AVAPIs.avSendIOCtrlExit(this.channelId);
         AVAPIs.avClientStop(this.channelId);
         IOTCAPIs.IOTC_Connect_Stop_BySID(this.connectId);
         IOTCAPIs.IOTC_Session_Close(this.sessionId);
         this.channelId = -1;
         this.connectId = -1;
      }

   }

   public int openTalkChannel() {
      this.talkChannelId = IOTCAPIs.IOTC_Session_Get_Free_Channel(this.connectId);
      byte[] speekStarByte = AVIOCTRLDEFs.SMsgAVIoctrlAVStream.parseContent(this.talkChannelId);
      int result = AVAPIs.avSendIOCtrl(this.channelId, 848, speekStarByte, speekStarByte.length);
      if (result >= 0) {
         AVAPIs.avSendIOCtrl(this.channelId, 769, speekStarByte, speekStarByte.length);
         this.talkServerId = AVAPIs.avServStart3(this.connectId, "", "", 0, 0, this.talkChannelId, new int[4]);
         return this.talkServerId;
      } else {
         return result;
      }
   }

   public int sendTalkData(int len, byte[] dataArr) {
      if (this.adutioFrameInfo == null) {
         this.adutioFrameInfo = AVIOCTRLDEFs.SFrameInfo.parseContent((short)138, (byte)0, (byte)0, (byte)0, 0);
      }

      int result = AVAPIs.avSendAudioData(this.talkServerId, dataArr, len, this.adutioFrameInfo, this.adutioFrameInfo.length);
      return result;
   }

   public int closeTalk() {
      byte[] speekStopByte = AVIOCTRLDEFs.SMsgAVIoctrlAVStream.parseContent(this.talkServerId);
      int ret1 = AVAPIs.avSendIOCtrl(this.connectId, 849, speekStopByte, speekStopByte.length);
      int ret2 = AVAPIs.avSendIOCtrl(this.connectId, 768, speekStopByte, speekStopByte.length);
      if (this.talkServerId >= 0) {
         AVAPIs.avServStop(this.talkServerId);
      }

      int ret3 = -1;
      if (this.connectId >= 0) {
         AVAPIs.avServExit(this.connectId, this.talkServerId);
         AVAPIs.avServExit(this.connectId, this.talkChannelId);
         ret3 = IOTCAPIs.IOTC_Session_Channel_OFF(this.connectId, this.talkChannelId);
      }

      try {
         Thread.sleep(500L);
      } catch (InterruptedException var6) {
         var6.printStackTrace();
      }

      Log.e("TutkManager", "closeTalk: " + ret1 + "-" + ret2 + "-" + ret3);
      return ret1 == 0 && ret2 == 0 && ret3 >= 0 ? 0 : -1;
   }

   private int byte2int(byte[] res) {
      int targets = res[0] & 255 | res[1] << 8 & '\uff00' | res[2] << 24 >>> 8 | res[3] << 24;
      return targets;
   }

   // $FF: synthetic method
   TutkManager(Object x0) {
      this();
   }

   static {
      System.loadLibrary("AVAPIs");
      System.loadLibrary("IOTCAPIs");
   }

   class ReleaseTask extends AsyncTask<Void, Void, Void> {
      protected Void doInBackground(Void... v) {
         Log.e("TutkManager", "ReleaseTask doInBackground: ");
         TutkManager.this.stop();
         return null;
      }

      protected void onPostExecute(Void result) {
      }
   }

   class GetAudioTask extends AsyncTask<Integer, Void, Void> {
      protected Void doInBackground(Integer... avIndex) {
         Log.e("TutkManager", "GetAudioTask doInBackground: ");

         for(; TutkManager.this.audioLoop; TutkManager.this.getAudioStream(avIndex[0])) {
            try {
               Thread.sleep(2L);
            } catch (InterruptedException var3) {
               var3.printStackTrace();
            }
         }

         return null;
      }

      protected void onPostExecute(Void result) {
      }
   }

   class GetVideoTask extends AsyncTask<Integer, Void, Void> {
      protected Void doInBackground(Integer... avIndex) {
         Log.e("TutkManager", "GetVideoTask doInBackground: ");

         for(; TutkManager.this.videoLoop; TutkManager.this.getVideoStream(avIndex[0])) {
            try {
               Thread.sleep(2L);
            } catch (InterruptedException var3) {
               var3.printStackTrace();
            }
         }

         return null;
      }

      protected void onPostExecute(Void result) {
      }
   }

   class ClientStartTask extends AsyncTask<TutkManager.TutkParam, Void, Boolean> {
      int index = -1;

      protected Boolean doInBackground(TutkManager.TutkParam... params) {
         int avIndex = TutkManager.this.clientStart(params[0].uid, params[0].account, params[0].pwd);
         Log.e("TutkManager", "clientStart: " + avIndex);
         if (avIndex >= 0) {
            this.index = avIndex;
            TutkManager.this.channelId = avIndex;
            return TutkManager.this.startIpcamStream(avIndex);
         } else {
            return false;
         }
      }

      protected void onPostExecute(Boolean result) {
         Log.e("TutkManager", "startIpcamStream: " + result);
         if (result) {
            TutkManager.this.videoLoop = true;
            TutkManager.this.audioLoop = true;
            (TutkManager.this.new GetVideoTask()).executeOnExecutor(TutkManager.this.newCachedThreadPool, new Integer[]{this.index});
            (TutkManager.this.new GetAudioTask()).executeOnExecutor(TutkManager.this.newCachedThreadPool, new Integer[]{this.index});
         }

      }
   }

   class TutkParam {
      public String uid;
      public String account;
      public String pwd;

      public TutkParam(String uid, String account, String pwd) {
         this.uid = uid;
         this.account = account;
         this.pwd = pwd;
      }
   }

   private static class SingletonHolder {
      private static final TutkManager instance = new TutkManager();
   }
}
