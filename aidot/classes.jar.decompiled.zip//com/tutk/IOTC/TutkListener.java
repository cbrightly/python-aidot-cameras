package com.tutk.IOTC;

public interface TutkListener {
   void OnReceiveAudioData(int var1, long var2, byte[] var4);

   void OnreceiveVideoData(int var1, long var2, byte[] var4);
}
