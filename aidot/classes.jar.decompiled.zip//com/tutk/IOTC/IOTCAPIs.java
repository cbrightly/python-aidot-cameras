package com.tutk.IOTC;

public class IOTCAPIs {
   public static final int API_ER_ANDROID_NULL = -10000;
   public static final int IOTC_ER_NoERROR = 0;
   public static final int IOTC_ER_SERVER_NOT_RESPONSE = -1;
   public static final int IOTC_ER_FAIL_RESOLVE_HOSTNAME = -2;
   public static final int IOTC_ER_ALREADY_INITIALIZED = -3;
   public static final int IOTC_ER_FAIL_CREATE_MUTEX = -4;
   public static final int IOTC_ER_FAIL_CREATE_THREAD = -5;
   public static final int IOTC_ER_FAIL_CREATE_SOCKET = -6;
   public static final int IOTC_ER_FAIL_SOCKET_OPT = -7;
   public static final int IOTC_ER_FAIL_SOCKET_BIND = -8;
   public static final int IOTC_ER_UNLICENSE = -10;
   public static final int IOTC_ER_LOGIN_ALREADY_CALLED = -11;
   public static final int IOTC_ER_NOT_INITIALIZED = -12;
   public static final int IOTC_ER_TIMEOUT = -13;
   public static final int IOTC_ER_INVALID_SID = -14;
   public static final int IOTC_ER_UNKNOWN_DEVICE = -15;
   public static final int IOTC_ER_FAIL_GET_LOCAL_IP = -16;
   public static final int IOTC_ER_LISTEN_ALREADY_CALLED = -17;
   public static final int IOTC_ER_EXCEED_MAX_SESSION = -18;
   public static final int IOTC_ER_CAN_NOT_FIND_DEVICE = -19;
   public static final int IOTC_ER_CONNECT_IS_CALLING = -20;
   public static final int IOTC_ER_SESSION_CLOSE_BY_REMOTE = -22;
   public static final int IOTC_ER_REMOTE_TIMEOUT_DISCONNECT = -23;
   public static final int IOTC_ER_DEVICE_NOT_LISTENING = -24;
   public static final int IOTC_ER_CH_NOT_ON = -26;
   public static final int IOTC_ER_FAIL_CONNECT_SEARCH = -27;
   public static final int IOTC_ER_MASTER_TOO_FEW = -28;
   public static final int IOTC_ER_AES_CERTIFY_FAIL = -29;
   public static final int IOTC_ER_SESSION_NO_FREE_CHANNEL = -31;
   public static final int IOTC_ER_TCP_TRAVEL_FAILED = -32;
   public static final int IOTC_ER_TCP_CONNECT_TO_SERVER_FAILED = -33;
   public static final int IOTC_ER_CLIENT_NOT_SECURE_MODE = -34;
   public static final int IOTC_ER_CLIENT_SECURE_MODE = -35;
   public static final int IOTC_ER_DEVICE_NOT_SECURE_MODE = -36;
   public static final int IOTC_ER_DEVICE_SECURE_MODE = -37;
   public static final int IOTC_ER_INVALID_MODE = -38;
   public static final int IOTC_ER_EXIT_LISTEN = -39;
   public static final int IOTC_ER_NO_PERMISSION = -40;
   public static final int IOTC_ER_NETWORK_UNREACHABLE = -41;
   public static final int IOTC_ER_FAIL_SETUP_RELAY = -42;
   public static final int IOTC_ER_NOT_SUPPORT_RELAY = -43;
   public static final int IOTC_ER_NO_SERVER_LIST = -44;
   public static final int IOTC_ER_DEVICE_MULTI_LOGIN = -45;
   public static final int IOTC_ER_INVALID_ARG = -46;
   public static final int IOTC_ER_NOT_SUPPORT_PE = -47;
   public static final int IOTC_ER_DEVICE_EXCEED_MAX_SESSION = -48;
   public static final int IOTC_ER_BLOCKED_CALL = -49;
   public static final int IOTC_ER_SESSION_CLOSED = -50;
   public static final int IOTC_ER_REMOTE_NOT_SUPPORTED = -51;
   public static final int IOTC_ER_ABORTED = -52;
   public static final int IOTC_ER_EXCEED_MAX_PACKET_SIZE = -53;
   public static final int IOTC_ER_SERVER_NOT_SUPPORT = -54;
   public static final int IOTC_ER_NO_PATH_TO_WRITE_DATA = -55;
   public static final int IOTC_ER_SERVICE_IS_NOT_STARTED = -56;
   public static final int IOTC_ER_STILL_IN_PROCESSING = -57;
   public static final int IOTC_ER_NOT_ENOUGH_MEMORY = -58;
   public static final int IOTC_ER_DEVICE_OFFLINE = -90;

   public static native int IOTC_Initialize2(int var0);

   public static native void IOTC_Set_Max_Session_Number(int var0);

   public static native int IOTC_DeInitialize();

   public static native int IOTC_Get_SessionID();

   public static native int IOTC_Connect_ByUID_Parallel(String var0, int var1);

   public static native int IOTC_Session_Get_Free_Channel(int var0);

   public static native int IOTC_Session_Channel_OFF(int var0, int var1);

   public static native int IOTC_Connect_Stop_BySID(int var0);

   public static native void IOTC_Session_Close(int var0);
}
