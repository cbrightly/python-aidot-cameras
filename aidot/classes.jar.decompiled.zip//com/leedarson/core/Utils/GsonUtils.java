package com.leedarson.core.Utils;

import android.text.TextUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.internal.LinkedTreeMap;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class GsonUtils {
   public static String getJsonString(Object object) {
      if (object == null) {
         return "";
      } else {
         Gson gson = (new GsonBuilder()).serializeNulls().registerTypeAdapter(Double.class, new JsonSerializer<Double>() {
            public JsonElement serialize(Double src, Type typeOfSrc, JsonSerializationContext context) {
               return src == (double)src.longValue() ? new JsonPrimitive(src.longValue()) : new JsonPrimitive(src);
            }
         }).disableHtmlEscaping().create();
         return gson.toJson(object);
      }
   }

   public static Object getJsonBean(String responseData, Class c) {
      if (responseData == null) {
         return null;
      } else {
         Gson gson = (new GsonBuilder()).serializeNulls().create();
         return gson.fromJson(responseData, c);
      }
   }

   public static Map<String, String> getJsonMap(String jsonData) {
      Gson gson = new Gson();
      Map<String, String> map = (Map)gson.fromJson(jsonData, HashMap.class);
      return map;
   }

   public static LinkedTreeMap getJsonLinkedTree(String jsonData) {
      if (TextUtils.isEmpty(jsonData)) {
         return null;
      } else {
         Gson gson = (new GsonBuilder()).disableHtmlEscaping().create();
         LinkedTreeMap map = (LinkedTreeMap)gson.fromJson(jsonData, LinkedTreeMap.class);
         return map;
      }
   }
}
