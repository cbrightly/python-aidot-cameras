package com.leedarson.core.Utils;

import android.text.TextUtils;
import android.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AESUtils {
   private static final String ECB_PKCS7_PADDING = "AES/ECB/PKCS7Padding";
   private static final String AES = "AES";

   public static byte[] get32Key(byte[] seed) {
      byte[] raw = new byte[32];

      for(int i = 0; i < seed.length; ++i) {
         raw[i] = seed[i];
      }

      return raw;
   }

   public static String encrypt(String key, String cleartext) {
      if (TextUtils.isEmpty(cleartext)) {
         return cleartext;
      } else {
         try {
            byte[] result = encrypt(key, cleartext.getBytes());
            return new String(Base64.encode(result, 0));
         } catch (Exception var3) {
            var3.printStackTrace();
            return null;
         }
      }
   }

   public static byte[] encrypt(String key, byte[] clear) throws Exception {
      byte[] raw = get32Key(key.getBytes());
      SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS7Padding");
      cipher.init(1, skeySpec);
      byte[] encrypted = cipher.doFinal(clear);
      return encrypted;
   }

   public static String decrypt(String key, String encrypted) {
      if (TextUtils.isEmpty(encrypted)) {
         return encrypted;
      } else {
         try {
            byte[] enc = Base64.decode(encrypted, 0);
            byte[] result = decrypt(key, enc);
            return new String(result);
         } catch (Exception var4) {
            var4.printStackTrace();
            return null;
         }
      }
   }

   public static byte[] decrypt(String key, byte[] encrypted) throws Exception {
      byte[] raw = get32Key(key.getBytes());
      SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS7Padding");
      cipher.init(2, skeySpec);
      byte[] decrypted = cipher.doFinal(encrypted);
      return decrypted;
   }
}
