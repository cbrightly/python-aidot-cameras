package com.leedarson.core.Utils;

public class Utils {
   public static int compareVersion(String newVersionStr, String oldVersionStr) {
      if (newVersionStr.equals(oldVersionStr)) {
         return 0;
      } else {
         int newVersion = 0;
         int oldVersion = 0;

         try {
            newVersion = Integer.parseInt(newVersionStr.replace("V", "").replace("v", "").replace(".", ""));
            oldVersion = Integer.parseInt(oldVersionStr.replace("V", "").replace("v", "").replace(".", ""));
         } catch (Exception var5) {
         }

         return newVersion - oldVersion;
      }
   }

   public static byte[] hexToBytes(String hexString) {
      if (hexString != null && !hexString.equals("")) {
         int length = hexString.length() / 2;
         char[] hexChars = hexString.toCharArray();
         byte[] bytes = new byte[length];
         String hexDigits = "0123456789abcdef";

         for(int i = 0; i < length; ++i) {
            int pos = i * 2;
            int h = hexDigits.indexOf(hexChars[pos]) << 4;
            int l = hexDigits.indexOf(hexChars[pos + 1]);
            if (h == -1 || l == -1) {
               return null;
            }

            bytes[i] = (byte)(h | l);
         }

         return bytes;
      } else {
         return null;
      }
   }

   public static short byteToShortBig(byte[] b) {
      short s = false;
      short s0 = (short)(b[1] & 255);
      short s1 = (short)(b[0] & 255);
      s1 = (short)(s1 << 8);
      short s = (short)(s0 | s1);
      return s;
   }

   public static int byte2intBig(byte[] res) {
      int targets = res[3] & 255 | res[2] << 8 & '\uff00' | res[1] << 24 >>> 8 | res[0] << 24;
      return targets;
   }

   public static long byte2longBig(byte[] res) {
      long num = 0L;

      for(int ix = 0; ix < 8; ++ix) {
         num <<= 8;
         num |= (long)(res[ix] & 255);
      }

      return num;
   }
}
