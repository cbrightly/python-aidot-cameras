package com.leedarson.core.udp.listener;

public interface UdpResponseListener {
   void onResponse(String var1);

   void onError(int var1, String var2);
}
