package com.leedarson.core.udp;

import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import com.leedarson.core.Utils.AESUtils;
import com.leedarson.core.udp.bean.UdpReq;
import com.leedarson.core.udp.listener.UdpResponseListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class UdpManager {
   private static final String TAG = "UdpManager";
   private static final int TIMEOUT = 15000;
   private static final String AES_KEY = "T54uednca587";
   private boolean isRecBroad = false;
   ExecutorService newCachedThreadPool = Executors.newCachedThreadPool();

   public static UdpManager getInstance() {
      return UdpManager.SingletonHolder.INSTANCE;
   }

   public void send(String ip, int port, String message, boolean isEncrypt, UdpResponseListener listener) {
      UdpReq udpReq = new UdpReq();
      udpReq.setIp(ip);
      udpReq.setPort(port);
      udpReq.setMessage(message);
      udpReq.setEncrypt(isEncrypt);
      udpReq.setListener(listener);
      this.isRecBroad = true;
      (new UdpManager.SendTask()).executeOnExecutor(this.newCachedThreadPool, new UdpReq[]{udpReq});
   }

   private void udpSend(String ip, int port, String message, boolean isEncrypt, UdpResponseListener listener) {
      try {
         DatagramSocket datagramSocket = new DatagramSocket();
         datagramSocket.setSoTimeout(15000);
         InetAddress inetAddress = null;
         if (TextUtils.isEmpty(ip)) {
            inetAddress = InetAddress.getByName("255.255.255.255");
         } else {
            inetAddress = InetAddress.getByName(ip);
         }

         byte[] messageBytes = null;
         byte[] messageBytes;
         if (isEncrypt) {
            messageBytes = AESUtils.encrypt("T54uednca587", message.getBytes());
         } else {
            messageBytes = message.getBytes();
         }

         DatagramPacket datagramPacket = new DatagramPacket(messageBytes, messageBytes.length, inetAddress, port);
         byte[] rec_bytes = new byte[1024];
         datagramSocket.send(datagramPacket);

         for(DatagramPacket recePacket = new DatagramPacket(rec_bytes, rec_bytes.length); this.isRecBroad; recePacket = new DatagramPacket(rec_bytes, rec_bytes.length)) {
            Log.e("UdpManager", "udpBroadcast rece: ");
            datagramSocket.receive(recePacket);
            byte[] rel_data = new byte[recePacket.getLength()];
            System.arraycopy(recePacket.getData(), 0, rel_data, 0, recePacket.getLength());
            byte[] data_bytes = null;
            if (isEncrypt) {
               try {
                  data_bytes = AESUtils.decrypt("T54uednca587", rel_data);
               } catch (Exception var19) {
                  var19.printStackTrace();
               }
            } else {
               data_bytes = rel_data;
            }

            String strMsg = (new String(data_bytes)).trim();
            String device_ip = recePacket.getAddress().getHostAddress().toString();
            int dev_port = recePacket.getPort();
            JSONObject jsonObject1 = new JSONObject(strMsg);
            if (isEncrypt) {
               jsonObject1.put("isEncrypt", 1);
            } else {
               jsonObject1.put("isEncrypt", 0);
            }

            if (jsonObject1.has("payload")) {
               JSONObject paloadObject = jsonObject1.getJSONObject("payload");
               paloadObject.put("ip", device_ip);
               paloadObject.put("port", dev_port);
            }

            String respMsg = jsonObject1.toString();
            if (respMsg != null && listener != null) {
               listener.onResponse(respMsg);
            }

            rec_bytes = new byte[1024];
         }
      } catch (Exception var20) {
         var20.printStackTrace();
         if (listener != null) {
            listener.onError(-1, "time out");
         }
      }

   }

   class SendTask extends AsyncTask<UdpReq, Void, Void> {
      protected Void doInBackground(UdpReq... reqs) {
         UdpReq req = reqs[0];
         if (req != null) {
            UdpManager.this.udpSend(req.getIp(), req.getPort(), req.getMessage(), req.isEncrypt(), req.getListener());
         }

         return null;
      }
   }

   private static class SingletonHolder {
      private static final UdpManager INSTANCE = new UdpManager();
   }
}
