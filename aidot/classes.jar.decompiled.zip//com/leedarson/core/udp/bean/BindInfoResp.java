package com.leedarson.core.udp.bean;

public class BindInfoResp {
   private String service;
   private String method;
   private String seq;
   private String srcAddr;
   private BindInfoResp.PayloadBean payload;
   private BindInfoResp.AckBean ack;
   private int isEncrypt;

   public String getService() {
      return this.service;
   }

   public void setService(String service) {
      this.service = service;
   }

   public String getMethod() {
      return this.method;
   }

   public void setMethod(String method) {
      this.method = method;
   }

   public String getSeq() {
      return this.seq;
   }

   public void setSeq(String seq) {
      this.seq = seq;
   }

   public String getSrcAddr() {
      return this.srcAddr;
   }

   public void setSrcAddr(String srcAddr) {
      this.srcAddr = srcAddr;
   }

   public BindInfoResp.PayloadBean getPayload() {
      return this.payload;
   }

   public void setPayload(BindInfoResp.PayloadBean payload) {
      this.payload = payload;
   }

   public BindInfoResp.AckBean getAck() {
      return this.ack;
   }

   public void setAck(BindInfoResp.AckBean ack) {
      this.ack = ack;
   }

   public int getIsEncrypt() {
      return this.isEncrypt;
   }

   public void setIsEncrypt(int isEncrypt) {
      this.isEncrypt = isEncrypt;
   }

   public static class AckBean {
      private int code;
      private String desc;

      public int getCode() {
         return this.code;
      }

      public void setCode(int code) {
         this.code = code;
      }

      public String getDesc() {
         return this.desc;
      }

      public void setDesc(String desc) {
         this.desc = desc;
      }
   }

   public static class PayloadBean {
      private String timestamp;
      private String devId;
      private String ip;
      private int port;

      public String getTimestamp() {
         return this.timestamp;
      }

      public void setTimestamp(String timestamp) {
         this.timestamp = timestamp;
      }

      public String getDevId() {
         return this.devId;
      }

      public void setDevId(String devId) {
         this.devId = devId;
      }

      public String getIp() {
         return this.ip;
      }

      public void setIp(String ip) {
         this.ip = ip;
      }

      public int getPort() {
         return this.port;
      }

      public void setPort(int port) {
         this.port = port;
      }
   }
}
