package com.leedarson.core.udp.bean;

import com.leedarson.core.udp.listener.UdpResponseListener;

public class UdpReq {
   private String ip;
   private int port;
   private String message;
   private boolean isEncrypt;
   private UdpResponseListener listener;

   public String getIp() {
      return this.ip;
   }

   public void setIp(String ip) {
      this.ip = ip;
   }

   public int getPort() {
      return this.port;
   }

   public void setPort(int port) {
      this.port = port;
   }

   public String getMessage() {
      return this.message;
   }

   public void setMessage(String message) {
      this.message = message;
   }

   public boolean isEncrypt() {
      return this.isEncrypt;
   }

   public void setEncrypt(boolean encrypt) {
      this.isEncrypt = encrypt;
   }

   public UdpResponseListener getListener() {
      return this.listener;
   }

   public void setListener(UdpResponseListener listener) {
      this.listener = listener;
   }
}
