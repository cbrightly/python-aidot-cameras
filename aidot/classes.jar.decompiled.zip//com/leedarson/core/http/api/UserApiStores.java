package com.leedarson.core.http.api;

import io.reactivex.Observable;
import java.util.Map;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.HeaderMap;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import retrofit2.http.Url;

public interface UserApiStores {
   @GET
   Observable<String> getHttp(@Url String var1, @QueryMap Map<String, Object> var2);

   @GET
   Observable<String> getHttp(@Url String var1, @QueryMap Map<String, Object> var2, @HeaderMap Map<String, Object> var3);

   @GET
   Observable<String> getHttp(@Url String var1);

   @GET
   Observable<String> getHttpWithHeader(@Url String var1, @HeaderMap Map<String, Object> var2);

   @POST
   Observable<String> postHttpJson(@Url String var1, @Body RequestBody var2);

   @POST
   Observable<String> postHttp(@Url String var1, @QueryMap Map<String, Object> var2);

   @POST
   Observable<String> postHttpJson(@Url String var1, @Body RequestBody var2, @HeaderMap Map<String, Object> var3);

   @POST
   Observable<String> postHttpJson(@Url String var1, @QueryMap Map<String, Object> var2, @HeaderMap Map<String, Object> var3);
}
