package com.leedarson.core.http.listener;

public interface HttpRequestListener {
   void cancel();
}
