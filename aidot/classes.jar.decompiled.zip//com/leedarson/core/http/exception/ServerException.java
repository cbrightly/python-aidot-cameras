package com.leedarson.core.http.exception;

public class ServerException extends RuntimeException {
   private int code;
   private String msg;

   public ServerException(int code, String msg) {
      this.code = code;
      this.msg = msg;
   }

   public int getCode() {
      return this.code;
   }

   public String getMsg() {
      return this.msg;
   }
}
