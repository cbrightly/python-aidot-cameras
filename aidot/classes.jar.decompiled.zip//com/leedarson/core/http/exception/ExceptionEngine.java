package com.leedarson.core.http.exception;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import javax.net.ssl.SSLHandshakeException;
import okhttp3.ResponseBody;
import org.json.JSONObject;
import retrofit2.HttpException;

public class ExceptionEngine {
   public static final int UN_KNOWN_ERROR = -1000;
   public static final int CONNECT_ERROR = -1009;
   public static final int TIME_OUT_ERROR = -1001;

   public static ApiException handleException(Throwable e) {
      ApiException ex;
      if (e instanceof HttpException) {
         ResponseBody body = ((HttpException)e).response().errorBody();
         int errCode = 0;
         String errMsg = "";

         try {
            String content = body.string();
            JSONObject data = new JSONObject(content);
            if (data != null) {
               errCode = data.getInt("code");
               errMsg = data.getString("desc");
            }
         } catch (Exception var7) {
            var7.printStackTrace();
         }

         HttpException httpExc = (HttpException)e;
         ex = new ApiException(e, httpExc.code());
         if (errMsg != null && !"".equals(errMsg)) {
            ex.setCode(errCode);
            ex.setMsg(errMsg);
         } else {
            ex.setMsg(httpExc.getMessage());
         }

         return ex;
      } else if (e instanceof ServerException) {
         ServerException serverExc = (ServerException)e;
         ex = new ApiException(serverExc, serverExc.getCode());
         ex.setMsg(serverExc.getMsg());
         return ex;
      } else if (!(e instanceof ConnectException) && !(e instanceof UnknownHostException)) {
         if (e instanceof SocketTimeoutException) {
            ex = new ApiException(e, -1001);
            ex.setMsg("Network Timeout");
            return ex;
         } else if (e instanceof SSLHandshakeException) {
            ex = new ApiException(e, -1000);
            ex.setMsg("Unreachable server, please check the network.");
            return ex;
         } else {
            ex = new ApiException(e, -1000);
            ex.setMsg(e.getMessage());
            return ex;
         }
      } else {
         ex = new ApiException(e, -1009);
         ex.setMsg(" The network disconnected.Please Check the network !");
         return ex;
      }
   }
}
