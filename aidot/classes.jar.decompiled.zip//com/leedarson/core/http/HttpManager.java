package com.leedarson.core.http;

import android.text.TextUtils;
import com.leedarson.core.http.api.UserApiStores;
import com.leedarson.core.http.observer.HttpRxObservable;
import com.leedarson.core.http.observer.HttpRxObserver;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.json.JSONException;
import org.json.JSONObject;

public class HttpManager {
   private HttpManager() {
   }

   public static HttpManager getInstance() {
      return HttpManager.SigletonHolder.INSTANCE;
   }

   public void requestHttpPost(String url, String header, String jsonData, HttpRxObserver<String> httpRxObserver) {
      httpRxObserver.setTag(url);
      RequestBody body = RequestBody.create(MediaType.parse("application/json"), jsonData);
      if (TextUtils.isEmpty(header)) {
         HttpRxObservable.getInstance().getObservable(((UserApiStores)RetrofitHelper.getInstance().getApiStores(UserApiStores.class)).postHttpJson(url, body)).subscribe(httpRxObserver);
      } else {
         HttpRxObservable.getInstance().getObservable(((UserApiStores)RetrofitHelper.getInstance().getApiStores(UserApiStores.class)).postHttpJson(url, body, this.getJsonMap(header))).subscribe(httpRxObserver);
      }

   }

   public void requestHttpPostForm(String url, String header, String jsonData, HttpRxObserver<String> httpRxObserver) {
      httpRxObserver.setTag(url);
      if (TextUtils.isEmpty(header)) {
         HttpRxObservable.getInstance().getObservable(((UserApiStores)RetrofitHelper.getInstance().getApiStores(UserApiStores.class)).postHttp(url, this.getJsonMap(jsonData))).subscribe(httpRxObserver);
      } else {
         HttpRxObservable.getInstance().getObservable(((UserApiStores)RetrofitHelper.getInstance().getApiStores(UserApiStores.class)).postHttpJson(url, this.getJsonMap(jsonData), this.getJsonMap(header))).subscribe(httpRxObserver);
      }

   }

   public void requestHttpGet(String url, String header, String jsonData, HttpRxObserver<String> httpRxObserver) {
      httpRxObserver.setTag(url);
      if (TextUtils.isEmpty(header)) {
         if (TextUtils.isEmpty(jsonData)) {
            HttpRxObservable.getInstance().getObservable(((UserApiStores)RetrofitHelper.getInstance().getApiStores(UserApiStores.class)).getHttp(url)).subscribe(httpRxObserver);
         } else {
            HttpRxObservable.getInstance().getObservable(((UserApiStores)RetrofitHelper.getInstance().getApiStores(UserApiStores.class)).getHttp(url, this.getJsonMap(jsonData))).subscribe(httpRxObserver);
         }
      } else if (TextUtils.isEmpty(jsonData)) {
         HttpRxObservable.getInstance().getObservable(((UserApiStores)RetrofitHelper.getInstance().getApiStores(UserApiStores.class)).getHttpWithHeader(url, this.getJsonMap(header))).subscribe(httpRxObserver);
      } else {
         HttpRxObservable.getInstance().getObservable(((UserApiStores)RetrofitHelper.getInstance().getApiStores(UserApiStores.class)).getHttp(url, this.getJsonMap(jsonData), this.getJsonMap(header))).subscribe(httpRxObserver);
      }

   }

   private Map<String, Object> getJsonMap(String jsonData) {
      try {
         JSONObject jsonObject = new JSONObject(jsonData);
         Iterator<String> keyIter = jsonObject.keys();
         HashMap valueMap = new HashMap();

         while(keyIter.hasNext()) {
            String key = (String)keyIter.next();
            Object value = jsonObject.get(key);
            valueMap.put(key, value);
         }

         return valueMap;
      } catch (JSONException var7) {
         var7.printStackTrace();
         return null;
      }
   }

   // $FF: synthetic method
   HttpManager(Object x0) {
      this();
   }

   private static class SigletonHolder {
      private static HttpManager INSTANCE = new HttpManager();
   }
}
