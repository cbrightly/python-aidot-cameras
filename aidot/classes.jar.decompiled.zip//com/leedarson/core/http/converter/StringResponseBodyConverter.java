package com.leedarson.core.http.converter;

import java.io.BufferedReader;
import java.io.IOException;
import okhttp3.ResponseBody;
import org.json.JSONObject;
import retrofit2.Converter;

public class StringResponseBodyConverter implements Converter<ResponseBody, String> {
   StringResponseBodyConverter(JSONObject jsonObject) {
   }

   public String convert(ResponseBody value) throws IOException {
      BufferedReader br = new BufferedReader(value.charStream());
      String line = "";
      StringBuffer buffer = new StringBuffer();

      while((line = br.readLine()) != null) {
         buffer.append(line);
      }

      return buffer.toString();
   }
}
