package com.leedarson.core.http.converter;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import org.json.JSONObject;
import retrofit2.Converter;
import retrofit2.Retrofit;
import retrofit2.Converter.Factory;

public class StringConverterFactory extends Factory {
   private static final MediaType MEDIA_TYPE = MediaType.parse("application/json; charset=UTF-8");
   private static final Charset UTF_8 = Charset.forName("UTF-8");
   private JSONObject jsonObject;

   private StringConverterFactory(JSONObject jsonObject) {
      if (jsonObject == null) {
         throw new NullPointerException("json == null");
      } else {
         this.jsonObject = jsonObject;
      }
   }

   public static StringConverterFactory create() {
      return new StringConverterFactory(new JSONObject());
   }

   public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations, Retrofit retrofit) {
      return new StringResponseBodyConverter(this.jsonObject);
   }

   public Converter<?, RequestBody> requestBodyConverter(Type type, Annotation[] parameterAnnotations, Annotation[] methodAnnotations, Retrofit retrofit) {
      return new StringRequestBodyConverter();
   }
}
