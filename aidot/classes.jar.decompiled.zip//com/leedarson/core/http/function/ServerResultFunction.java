package com.leedarson.core.http.function;

import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Function;

public class ServerResultFunction implements Function<String, String> {
   public String apply(@NonNull String response) throws Exception {
      return response;
   }
}
