package com.leedarson.core.http.function;

import com.leedarson.core.http.exception.ExceptionEngine;
import io.reactivex.Observable;
import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Function;

public class HttpResultFunction<String> implements Function<Throwable, Observable<String>> {
   public Observable<String> apply(@NonNull Throwable throwable) throws Exception {
      return Observable.error(ExceptionEngine.handleException(throwable));
   }
}
