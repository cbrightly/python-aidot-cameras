package com.leedarson.core.http;

import android.util.Log;
import com.leedarson.core.http.converter.StringConverterFactory;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import okhttp3.logging.HttpLoggingInterceptor.Level;
import okhttp3.logging.HttpLoggingInterceptor.Logger;
import retrofit2.Retrofit;
import retrofit2.Retrofit.Builder;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

public class RetrofitHelper {
   private Retrofit mRetrofit;
   public static final String BASE_HTTP_URL = "http://localhost/";
   public static final int CONNECT_TIME_OUT = 30;
   public static final int READ_TIME_OUT = 30;
   public static final int WRITE_TIME_OUT = 30;

   private RetrofitHelper() {
      this.initRetrofit();
   }

   public static RetrofitHelper getInstance() {
      return RetrofitHelper.SingletonHolder.INSTANCE;
   }

   private void initRetrofit() {
      this.mRetrofit = (new Builder()).baseUrl("http://localhost/").addConverterFactory(StringConverterFactory.create()).addCallAdapterFactory(RxJava2CallAdapterFactory.create()).client(this.getOkHttpClient()).build();
   }

   public <T> T getApiStores(Class<T> stores) {
      return this.mRetrofit.create(stores);
   }

   private OkHttpClient getOkHttpClient() {
      Level level = Level.BODY;
      HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(new Logger() {
         public void log(String message) {
            Log.i("OkHttp", "log: " + message);
         }
      });
      loggingInterceptor.setLevel(level);
      okhttp3.OkHttpClient.Builder httpClientBuilder = new okhttp3.OkHttpClient.Builder();
      httpClientBuilder.addInterceptor(loggingInterceptor);
      httpClientBuilder.connectTimeout(30L, TimeUnit.SECONDS);
      httpClientBuilder.readTimeout(30L, TimeUnit.SECONDS);
      httpClientBuilder.writeTimeout(30L, TimeUnit.SECONDS);
      httpClientBuilder.retryOnConnectionFailure(true);
      return httpClientBuilder.build();
   }

   // $FF: synthetic method
   RetrofitHelper(Object x0) {
      this();
   }

   private static class SingletonHolder {
      private static final RetrofitHelper INSTANCE = new RetrofitHelper();
   }
}
