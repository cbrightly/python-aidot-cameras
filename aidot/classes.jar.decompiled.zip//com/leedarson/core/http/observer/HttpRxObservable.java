package com.leedarson.core.http.observer;

import com.leedarson.core.http.function.HttpResultFunction;
import com.leedarson.core.http.function.ServerResultFunction;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class HttpRxObservable<T> {
   private HttpRxObservable() {
   }

   public static HttpRxObservable getInstance() {
      return HttpRxObservable.SigletonHolder.INSTANCE;
   }

   public Observable<String> getObservable(Observable<String> apiObservable) {
      Observable observable = apiObservable.map(new ServerResultFunction()).onErrorResumeNext(new HttpResultFunction()).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
      return observable;
   }

   // $FF: synthetic method
   HttpRxObservable(Object x0) {
      this();
   }

   private static class SigletonHolder {
      private static HttpRxObservable INSTANCE = new HttpRxObservable();
   }
}
