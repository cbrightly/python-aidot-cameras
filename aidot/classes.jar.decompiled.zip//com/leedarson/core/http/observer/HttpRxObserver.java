package com.leedarson.core.http.observer;

import android.text.TextUtils;
import com.leedarson.core.http.exception.ApiException;
import com.leedarson.core.http.listener.HttpRequestListener;
import com.leedarson.core.http.manage.RxActionManagerImpl;
import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

public abstract class HttpRxObserver<T> implements Observer<T>, HttpRequestListener {
   private String mTag;

   public void setTag(String mTag) {
      this.mTag = mTag;
   }

   public void onError(Throwable e) {
      RxActionManagerImpl.getInstance().remove(this.mTag);
      if (e instanceof ApiException) {
         this.onError((ApiException)e);
      } else {
         this.onError(new ApiException(e, -1000));
      }

   }

   public void onComplete() {
   }

   public void onNext(@NonNull T t) {
      if (!TextUtils.isEmpty(this.mTag)) {
         RxActionManagerImpl.getInstance().remove(this.mTag);
      }

      this.onSuccess(t);
   }

   public void onSubscribe(@NonNull Disposable d) {
      if (!TextUtils.isEmpty(this.mTag)) {
         RxActionManagerImpl.getInstance().add(this.mTag, d);
      }

      this.onStart(d);
   }

   public void cancel() {
      if (!TextUtils.isEmpty(this.mTag)) {
         RxActionManagerImpl.getInstance().cancel(this.mTag);
      }

   }

   public boolean isDisposed() {
      return TextUtils.isEmpty(this.mTag) ? true : RxActionManagerImpl.getInstance().isDisposed(this.mTag);
   }

   protected abstract void onStart(Disposable var1);

   protected abstract void onError(ApiException var1);

   protected abstract void onSuccess(T var1);
}
