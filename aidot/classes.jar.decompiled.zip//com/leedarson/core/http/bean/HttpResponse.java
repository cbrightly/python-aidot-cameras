package com.leedarson.core.http.bean;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

public class HttpResponse<T> {
   @SerializedName("code")
   private int code;
   @SerializedName("desc")
   private String msg;
   @SerializedName("data")
   private T data;

   public HttpResponse(T data) {
      this.data = data;
   }

   public HttpResponse() {
   }

   public boolean isSuccess() {
      return this.code == 200;
   }

   public String toString() {
      String response = "{\"code\": " + this.code + ",\"msg\":" + this.msg + ",\"data\":" + (new Gson()).toJson(this.data) + "}";
      return response;
   }

   public int getCode() {
      return this.code;
   }

   public void setCode(int code) {
      this.code = code;
   }

   public String getMsg() {
      return this.msg;
   }

   public void setMsg(String msg) {
      this.msg = msg;
   }

   public T getData() {
      return this.data;
   }

   public void setData(T data) {
      this.data = data;
   }
}
