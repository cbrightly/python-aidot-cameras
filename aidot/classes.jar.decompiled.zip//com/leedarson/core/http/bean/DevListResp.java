package com.leedarson.core.http.bean;

import java.util.List;

public class DevListResp {
   private int code;
   private Object desc;
   private DevListResp.DataBean data;

   public int getCode() {
      return this.code;
   }

   public void setCode(int code) {
      this.code = code;
   }

   public Object getDesc() {
      return this.desc;
   }

   public void setDesc(Object desc) {
      this.desc = desc;
   }

   public DevListResp.DataBean getData() {
      return this.data;
   }

   public void setData(DevListResp.DataBean data) {
      this.data = data;
   }

   public static class DataBean {
      private int totalCount;
      private List<DevListResp.DataBean.DevBean> dev;

      public int getTotalCount() {
         return this.totalCount;
      }

      public void setTotalCount(int totalCount) {
         this.totalCount = totalCount;
      }

      public List<DevListResp.DataBean.DevBean> getDev() {
         return this.dev;
      }

      public void setDev(List<DevListResp.DataBean.DevBean> dev) {
         this.dev = dev;
      }

      public static class DevBean {
         private String devId;
         private String devType;
         private Object address;
         private String productId;
         private String icon;
         private String parentId;
         private String roomId;
         private String password;
         private int catalogId;
         private String name;
         private boolean online;
         private DevListResp.DataBean.DevBean.AttrBean attr;
         private String homeId;
         private long lastUpdateTime;
         private List<?> comMode;
         private List<Integer> otaInfo;

         public String getDevId() {
            return this.devId;
         }

         public void setDevId(String devId) {
            this.devId = devId;
         }

         public String getDevType() {
            return this.devType;
         }

         public void setDevType(String devType) {
            this.devType = devType;
         }

         public Object getAddress() {
            return this.address;
         }

         public void setAddress(Object address) {
            this.address = address;
         }

         public String getProductId() {
            return this.productId;
         }

         public void setProductId(String productId) {
            this.productId = productId;
         }

         public String getIcon() {
            return this.icon;
         }

         public void setIcon(String icon) {
            this.icon = icon;
         }

         public String getParentId() {
            return this.parentId;
         }

         public void setParentId(String parentId) {
            this.parentId = parentId;
         }

         public String getRoomId() {
            return this.roomId;
         }

         public void setRoomId(String roomId) {
            this.roomId = roomId;
         }

         public String getPassword() {
            return this.password;
         }

         public void setPassword(String password) {
            this.password = password;
         }

         public int getCatalogId() {
            return this.catalogId;
         }

         public void setCatalogId(int catalogId) {
            this.catalogId = catalogId;
         }

         public String getName() {
            return this.name;
         }

         public void setName(String name) {
            this.name = name;
         }

         public boolean isOnline() {
            return this.online;
         }

         public void setOnline(boolean online) {
            this.online = online;
         }

         public DevListResp.DataBean.DevBean.AttrBean getAttr() {
            return this.attr;
         }

         public void setAttr(DevListResp.DataBean.DevBean.AttrBean attr) {
            this.attr = attr;
         }

         public String getHomeId() {
            return this.homeId;
         }

         public void setHomeId(String homeId) {
            this.homeId = homeId;
         }

         public long getLastUpdateTime() {
            return this.lastUpdateTime;
         }

         public void setLastUpdateTime(long lastUpdateTime) {
            this.lastUpdateTime = lastUpdateTime;
         }

         public List<?> getComMode() {
            return this.comMode;
         }

         public void setComMode(List<?> comMode) {
            this.comMode = comMode;
         }

         public List<Integer> getOtaInfo() {
            return this.otaInfo;
         }

         public void setOtaInfo(List<Integer> otaInfo) {
            this.otaInfo = otaInfo;
         }

         public static class AttrBean {
            private String VideoAngle;
            private String SoundLevel;
            private String Language;
            private String MotionDetection;
            private String LedOnOff;

            public String getVideoAngle() {
               return this.VideoAngle;
            }

            public void setVideoAngle(String VideoAngle) {
               this.VideoAngle = VideoAngle;
            }

            public String getSoundLevel() {
               return this.SoundLevel;
            }

            public void setSoundLevel(String SoundLevel) {
               this.SoundLevel = SoundLevel;
            }

            public String getLanguage() {
               return this.Language;
            }

            public void setLanguage(String Language) {
               this.Language = Language;
            }

            public String getMotionDetection() {
               return this.MotionDetection;
            }

            public void setMotionDetection(String MotionDetection) {
               this.MotionDetection = MotionDetection;
            }

            public String getLedOnOff() {
               return this.LedOnOff;
            }

            public void setLedOnOff(String LedOnOff) {
               this.LedOnOff = LedOnOff;
            }
         }
      }
   }
}
