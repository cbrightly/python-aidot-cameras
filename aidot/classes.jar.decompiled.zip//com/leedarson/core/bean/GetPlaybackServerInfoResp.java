package com.leedarson.core.bean;

public class GetPlaybackServerInfoResp {
   private GetPlaybackServerInfoResp.AckBean ack;
   private String clientId;
   private String method;
   private GetPlaybackServerInfoResp.PayloadBean payload;
   private String seq;
   private String service;
   private String srcAddr;

   public GetPlaybackServerInfoResp.AckBean getAck() {
      return this.ack;
   }

   public void setAck(GetPlaybackServerInfoResp.AckBean ack) {
      this.ack = ack;
   }

   public String getClientId() {
      return this.clientId;
   }

   public void setClientId(String clientId) {
      this.clientId = clientId;
   }

   public String getMethod() {
      return this.method;
   }

   public void setMethod(String method) {
      this.method = method;
   }

   public GetPlaybackServerInfoResp.PayloadBean getPayload() {
      return this.payload;
   }

   public void setPayload(GetPlaybackServerInfoResp.PayloadBean payload) {
      this.payload = payload;
   }

   public String getSeq() {
      return this.seq;
   }

   public void setSeq(String seq) {
      this.seq = seq;
   }

   public String getService() {
      return this.service;
   }

   public void setService(String service) {
      this.service = service;
   }

   public String getSrcAddr() {
      return this.srcAddr;
   }

   public void setSrcAddr(String srcAddr) {
      this.srcAddr = srcAddr;
   }

   public static class PayloadBean {
      private String accessToken;
      private int heartbeat;
      private String serverIP;
      private int serverPort;
      private String serverProtocol;

      public String getAccessToken() {
         return this.accessToken;
      }

      public void setAccessToken(String accessToken) {
         this.accessToken = accessToken;
      }

      public int getHeartbeat() {
         return this.heartbeat;
      }

      public void setHeartbeat(int heartbeat) {
         this.heartbeat = heartbeat;
      }

      public String getServerIP() {
         return this.serverIP;
      }

      public void setServerIP(String serverIP) {
         this.serverIP = serverIP;
      }

      public int getServerPort() {
         return this.serverPort;
      }

      public void setServerPort(int serverPort) {
         this.serverPort = serverPort;
      }

      public String getServerProtocol() {
         return this.serverProtocol;
      }

      public void setServerProtocol(String serverProtocol) {
         this.serverProtocol = serverProtocol;
      }
   }

   public static class AckBean {
      private int code;
      private String desc;

      public int getCode() {
         return this.code;
      }

      public void setCode(int code) {
         this.code = code;
      }

      public String getDesc() {
         return this.desc;
      }

      public void setDesc(String desc) {
         this.desc = desc;
      }
   }
}
