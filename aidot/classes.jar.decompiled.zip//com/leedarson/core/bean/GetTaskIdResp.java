package com.leedarson.core.bean;

public class GetTaskIdResp {
   private int code;
   private Object desc;
   private GetTaskIdResp.DataBean data;

   public int getCode() {
      return this.code;
   }

   public void setCode(int code) {
      this.code = code;
   }

   public Object getDesc() {
      return this.desc;
   }

   public void setDesc(Object desc) {
      this.desc = desc;
   }

   public GetTaskIdResp.DataBean getData() {
      return this.data;
   }

   public void setData(GetTaskIdResp.DataBean data) {
      this.data = data;
   }

   public static class DataBean {
      private int port;
      private int taskId;
      private int heartbeat;

      public int getPort() {
         return this.port;
      }

      public void setPort(int port) {
         this.port = port;
      }

      public int getTaskId() {
         return this.taskId;
      }

      public void setTaskId(int taskId) {
         this.taskId = taskId;
      }

      public int getHeartbeat() {
         return this.heartbeat;
      }

      public void setHeartbeat(int heartbeat) {
         this.heartbeat = heartbeat;
      }
   }
}
