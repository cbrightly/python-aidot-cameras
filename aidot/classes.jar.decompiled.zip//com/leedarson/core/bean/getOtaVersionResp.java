package com.leedarson.core.bean;

import java.util.List;

public class getOtaVersionResp {
   private getOtaVersionResp.AckBean ack;
   private String clientId;
   private String method;
   private getOtaVersionResp.PayloadBean payload;
   private String seq;
   private String service;
   private String srcAddr;

   public getOtaVersionResp.AckBean getAck() {
      return this.ack;
   }

   public void setAck(getOtaVersionResp.AckBean ack) {
      this.ack = ack;
   }

   public String getClientId() {
      return this.clientId;
   }

   public void setClientId(String clientId) {
      this.clientId = clientId;
   }

   public String getMethod() {
      return this.method;
   }

   public void setMethod(String method) {
      this.method = method;
   }

   public getOtaVersionResp.PayloadBean getPayload() {
      return this.payload;
   }

   public void setPayload(getOtaVersionResp.PayloadBean payload) {
      this.payload = payload;
   }

   public String getSeq() {
      return this.seq;
   }

   public void setSeq(String seq) {
      this.seq = seq;
   }

   public String getService() {
      return this.service;
   }

   public void setService(String service) {
      this.service = service;
   }

   public String getSrcAddr() {
      return this.srcAddr;
   }

   public void setSrcAddr(String srcAddr) {
      this.srcAddr = srcAddr;
   }

   public static class PayloadBean {
      private String timestamp;
      private List<getOtaVersionResp.PayloadBean.VerListBean> verList;

      public String getTimestamp() {
         return this.timestamp;
      }

      public void setTimestamp(String timestamp) {
         this.timestamp = timestamp;
      }

      public List<getOtaVersionResp.PayloadBean.VerListBean> getVerList() {
         return this.verList;
      }

      public void setVerList(List<getOtaVersionResp.PayloadBean.VerListBean> verList) {
         this.verList = verList;
      }

      public static class VerListBean {
         private String devId;
         private int fwType;
         private String msg;
         private String newVersion;
         private String oldVersion;
         private int percent;
         private int stage;

         public String getDevId() {
            return this.devId;
         }

         public void setDevId(String devId) {
            this.devId = devId;
         }

         public int getFwType() {
            return this.fwType;
         }

         public void setFwType(int fwType) {
            this.fwType = fwType;
         }

         public String getMsg() {
            return this.msg;
         }

         public void setMsg(String msg) {
            this.msg = msg;
         }

         public String getNewVersion() {
            return this.newVersion;
         }

         public void setNewVersion(String newVersion) {
            this.newVersion = newVersion;
         }

         public String getOldVersion() {
            return this.oldVersion;
         }

         public void setOldVersion(String oldVersion) {
            this.oldVersion = oldVersion;
         }

         public int getPercent() {
            return this.percent;
         }

         public void setPercent(int percent) {
            this.percent = percent;
         }

         public int getStage() {
            return this.stage;
         }

         public void setStage(int stage) {
            this.stage = stage;
         }
      }
   }

   public static class AckBean {
      private int code;
      private String desc;

      public int getCode() {
         return this.code;
      }

      public void setCode(int code) {
         this.code = code;
      }

      public String getDesc() {
         return this.desc;
      }

      public void setDesc(String desc) {
         this.desc = desc;
      }
   }
}
