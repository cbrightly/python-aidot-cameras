package com.leedarson.core.bean;

import java.util.List;

public class GetRecordResp {
   private int code;
   private Object desc;
   private GetRecordResp.DataBean data;

   public int getCode() {
      return this.code;
   }

   public void setCode(int code) {
      this.code = code;
   }

   public Object getDesc() {
      return this.desc;
   }

   public void setDesc(Object desc) {
      this.desc = desc;
   }

   public GetRecordResp.DataBean getData() {
      return this.data;
   }

   public void setData(GetRecordResp.DataBean data) {
      this.data = data;
   }

   public static class DataBean {
      private int pageNum;
      private int pageSize;
      private int size;
      private int startRow;
      private int endRow;
      private int total;
      private int pages;
      private int prePage;
      private int nextPage;
      private boolean isFirstPage;
      private boolean isLastPage;
      private boolean hasPreviousPage;
      private boolean hasNextPage;
      private int navigatePages;
      private Object navigatepageNums;
      private int navigateFirstPage;
      private int navigateLastPage;
      private int firstPage;
      private int lastPage;
      private List<GetRecordResp.DataBean.ListBean> list;

      public int getPageNum() {
         return this.pageNum;
      }

      public void setPageNum(int pageNum) {
         this.pageNum = pageNum;
      }

      public int getPageSize() {
         return this.pageSize;
      }

      public void setPageSize(int pageSize) {
         this.pageSize = pageSize;
      }

      public int getSize() {
         return this.size;
      }

      public void setSize(int size) {
         this.size = size;
      }

      public int getStartRow() {
         return this.startRow;
      }

      public void setStartRow(int startRow) {
         this.startRow = startRow;
      }

      public int getEndRow() {
         return this.endRow;
      }

      public void setEndRow(int endRow) {
         this.endRow = endRow;
      }

      public int getTotal() {
         return this.total;
      }

      public void setTotal(int total) {
         this.total = total;
      }

      public int getPages() {
         return this.pages;
      }

      public void setPages(int pages) {
         this.pages = pages;
      }

      public int getPrePage() {
         return this.prePage;
      }

      public void setPrePage(int prePage) {
         this.prePage = prePage;
      }

      public int getNextPage() {
         return this.nextPage;
      }

      public void setNextPage(int nextPage) {
         this.nextPage = nextPage;
      }

      public boolean isIsFirstPage() {
         return this.isFirstPage;
      }

      public void setIsFirstPage(boolean isFirstPage) {
         this.isFirstPage = isFirstPage;
      }

      public boolean isIsLastPage() {
         return this.isLastPage;
      }

      public void setIsLastPage(boolean isLastPage) {
         this.isLastPage = isLastPage;
      }

      public boolean isHasPreviousPage() {
         return this.hasPreviousPage;
      }

      public void setHasPreviousPage(boolean hasPreviousPage) {
         this.hasPreviousPage = hasPreviousPage;
      }

      public boolean isHasNextPage() {
         return this.hasNextPage;
      }

      public void setHasNextPage(boolean hasNextPage) {
         this.hasNextPage = hasNextPage;
      }

      public int getNavigatePages() {
         return this.navigatePages;
      }

      public void setNavigatePages(int navigatePages) {
         this.navigatePages = navigatePages;
      }

      public Object getNavigatepageNums() {
         return this.navigatepageNums;
      }

      public void setNavigatepageNums(Object navigatepageNums) {
         this.navigatepageNums = navigatepageNums;
      }

      public int getNavigateFirstPage() {
         return this.navigateFirstPage;
      }

      public void setNavigateFirstPage(int navigateFirstPage) {
         this.navigateFirstPage = navigateFirstPage;
      }

      public int getNavigateLastPage() {
         return this.navigateLastPage;
      }

      public void setNavigateLastPage(int navigateLastPage) {
         this.navigateLastPage = navigateLastPage;
      }

      public int getFirstPage() {
         return this.firstPage;
      }

      public void setFirstPage(int firstPage) {
         this.firstPage = firstPage;
      }

      public int getLastPage() {
         return this.lastPage;
      }

      public void setLastPage(int lastPage) {
         this.lastPage = lastPage;
      }

      public List<GetRecordResp.DataBean.ListBean> getList() {
         return this.list;
      }

      public void setList(List<GetRecordResp.DataBean.ListBean> list) {
         this.list = list;
      }

      public static class ListBean {
         private long sta;
         private long end;

         public long getSta() {
            return this.sta;
         }

         public void setSta(long sta) {
            this.sta = sta;
         }

         public long getEnd() {
            return this.end;
         }

         public void setEnd(long end) {
            this.end = end;
         }
      }
   }
}
