package com.leedarson.core.tcp;

public interface SendRespListener {
   void success();

   void error();
}
