package com.leedarson.core.tcp;

import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import com.leedarson.core.mqtt.ObservableMessage;
import com.leedarson.core.tcp.callback.CommandCallback;
import com.leedarson.core.tcp.callback.DefaultCommandCallback;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import java.util.concurrent.TimeoutException;

public class INettyManager {
   private static final String TAG = "INettyManager";
   public static ArrayMap callbacks = new ArrayMap();
   private static final int TIMEOUT = 30;
   private INettyClient client;
   private Thread connectThrad;

   private INettyManager() {
      this.client = new INettyClient();
      this.connectThrad = null;
   }

   public static INettyManager getInstance() {
      return INettyManager.SingletonHolder.INSTANCE;
   }

   public void connect(final String inetHost, final int inetPort, final int heartbeat, final short cmd, final short subCmd, final int cmdParam, final INettyListener listener) {
      this.connectThrad = null;
      this.connectThrad = new Thread(new Runnable() {
         public void run() {
            INettyManager.this.client.setListener(listener);
            INettyManager.this.client.connect(inetHost, inetPort, heartbeat, cmd, subCmd, cmdParam);
         }
      });
      this.connectThrad.start();
   }

   public void disconnect() {
      if (this.client != null) {
         this.client.disconnect();
      }

   }

   public void sendTCPCommand(final RecordVideoMessage message, final CommandCallback callback) {
      Observable.create(new ObservableOnSubscribe<ObservableMessage>() {
         public void subscribe(@NonNull final ObservableEmitter<ObservableMessage> e) throws Exception {
            final ObservableMessage observableMessage = new ObservableMessage();
            if (!e.isDisposed()) {
               boolean isSend = false;
               if (INettyManager.this.client != null) {
                  isSend = true;
                  INettyManager.this.client.sendMessage(message, new SendRespListener() {
                     public void success() {
                     }

                     public void error() {
                     }
                  });
               }

               if (!isSend) {
                  observableMessage.flag = -1;
                  observableMessage.mCode = -1;
                  e.onNext(observableMessage);
                  e.onComplete();
               } else {
                  DefaultCommandCallback defaultCommandCallback = new DefaultCommandCallback() {
                     public void onSuccess(String service, String method, Object response, boolean isMQTT) {
                        super.onSuccess(service, method, response, isMQTT);
                        observableMessage.flag = 0;
                        observableMessage.mService = service;
                        observableMessage.mMethod = method;
                        observableMessage.mResponse = response;
                        observableMessage.mIsMQTT = isMQTT;
                        e.onNext(observableMessage);
                        e.onComplete();
                     }

                     public void onSuccess(Object response, boolean isMQTT) {
                        super.onSuccess(response, isMQTT);
                        observableMessage.flag = 0;
                        observableMessage.mResponse = response;
                        observableMessage.mIsMQTT = isMQTT;
                        e.onNext(observableMessage);
                        e.onComplete();
                     }

                     public void onFailure(int code, String errorStr) {
                        super.onFailure(code, errorStr);
                        observableMessage.flag = -1;
                        observableMessage.mCode = code;
                        observableMessage.mErrorStr = errorStr;
                        e.onNext(observableMessage);
                        e.onComplete();
                     }

                     public void onException(Throwable throwable) {
                        super.onException(throwable);
                        observableMessage.flag = -1;
                        observableMessage.mCode = -1;
                        e.onNext(observableMessage);
                        e.onComplete();
                     }
                  };
                  INettyManager.callbacks.put(message.getHeader().getSequence(), defaultCommandCallback);
               }
            }

         }
      }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<ObservableMessage>() {
         public void onSubscribe(@NonNull Disposable d) {
         }

         public void onNext(@NonNull ObservableMessage message1) {
            switch(message1.flag) {
            case -1:
               callback.onFailure(message1.mCode, message1.mErrorStr);
               break;
            case 0:
               callback.onSuccess(message1.mResponse, message1.mIsMQTT);
               break;
            case 1:
               callback.onSuccess(message1.mResponse, message1.mIsMQTT);
            }

         }

         public void onError(@NonNull Throwable e) {
            if (e instanceof TimeoutException) {
               callback.onFailure(-2, "TCP request time out");
            } else {
               callback.onFailure(-3, (String)null);
            }

         }

         public void onComplete() {
         }
      });
   }

   // $FF: synthetic method
   INettyManager(Object x0) {
      this();
   }

   private static class SingletonHolder {
      private static final INettyManager INSTANCE = new INettyManager();
   }
}
