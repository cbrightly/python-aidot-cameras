package com.leedarson.core.tcp;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

public class INettyClient {
   private static final String TAG = "INettyClient";
   private EventLoopGroup group;
   private Bootstrap bootstrap;
   private Channel channel;
   private boolean isConnect = false;
   private INettyListener listener;

   public void setListener(INettyListener listener) {
      if (listener == null) {
         throw new IllegalArgumentException("listener == null ");
      } else {
         this.listener = listener;
      }
   }

   public synchronized void connect(String inetHost, int inetPort, int heartbeat, short cmd, short subCmd, int cmdParam) {
      this.group = new NioEventLoopGroup();
      this.bootstrap = (Bootstrap)((Bootstrap)((Bootstrap)((Bootstrap)((Bootstrap)(new Bootstrap()).group(this.group)).option(ChannelOption.SO_KEEPALIVE, true)).option(ChannelOption.TCP_NODELAY, true)).channel(NioSocketChannel.class)).handler(new INettyClientInitializer(this.listener, heartbeat, cmd, subCmd, cmdParam));

      try {
         ChannelFuture future = this.bootstrap.connect(inetHost, inetPort).sync();
         if (future != null && future.isSuccess()) {
            this.channel = future.channel();
            this.isConnect = true;
         } else {
            this.isConnect = false;
         }
      } catch (Exception var8) {
         var8.printStackTrace();
         this.listener.onServiceStatusConnectChanged(0);
      }

   }

   public void disconnect() {
      this.isConnect = false;

      try {
         if (this.channel != null) {
            this.channel.close().sync();
         }

         if (this.group != null) {
            this.group.shutdownGracefully().sync();
         }
      } catch (Exception var2) {
         var2.printStackTrace();
      }

   }

   public boolean isConnect() {
      boolean flag = this.channel != null && this.isConnect;
      return flag;
   }

   public void setConnectStatus(boolean status) {
      this.isConnect = status;
   }

   public void sendMessage(RecordVideoMessage message, final SendRespListener listener) {
      this.channel.writeAndFlush(message).addListener(new FutureListener() {
         public void success() {
            listener.success();
         }

         public void error() {
            listener.error();
         }
      });
   }
}
