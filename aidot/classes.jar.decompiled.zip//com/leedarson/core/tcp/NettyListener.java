package com.leedarson.core.tcp;

public interface NettyListener {
   byte STATUS_CONNECT_SUCCESS = 1;
   byte STATUS_CONNECT_CLOSED = 2;
   byte STATUS_CONNECT_ERROR = 0;

   void onMessageResponse(String var1, String var2);

   void onServiceStatusConnectChanged(String var1, int var2);
}
