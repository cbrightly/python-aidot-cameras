package com.leedarson.core.tcp;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.handler.codec.MessageToMessageEncoder;
import io.netty.util.CharsetUtil;
import java.util.List;

@Sharable
public class RecordVideoEncoder extends MessageToMessageEncoder<RecordVideoMessage> {
   public static final RecordVideoEncoder INSTANCE = new RecordVideoEncoder();

   private RecordVideoEncoder() {
   }

   protected void encode(ChannelHandlerContext ctx, RecordVideoMessage msg, List<Object> out) throws Exception {
      out.add(doEncode(ctx.alloc(), msg));
   }

   private static ByteBuf doEncode(ByteBufAllocator byteBufAllocator, RecordVideoMessage message) {
      int payloadLen = message.getPayload() != null ? message.getPayload().length : 0;
      ByteBuf buf = byteBufAllocator.buffer(payloadLen + 37);
      RecordVideoHeader header = message.getHeader();
      buf.writeShort(header.getVersion());
      buf.writeInt(header.getSequence());
      buf.writeShort(header.getCmd());
      buf.writeShort(header.getSubCmd());
      buf.writeInt(header.getCmdParam());
      buf.writeInt(payloadLen);
      buf.writeLong(header.getTimeStamp());
      buf.writeInt(header.getContext());
      buf.writeByte(header.getEncodeType());
      buf.writeShort(header.getResult());
      buf.writeInt(header.getReserve());
      if (payloadLen > 0) {
         buf.writeBytes(message.getPayload());
      }

      return buf;
   }

   static byte[] encodeStringUtf8(String s) {
      return s.getBytes(CharsetUtil.UTF_8);
   }
}
