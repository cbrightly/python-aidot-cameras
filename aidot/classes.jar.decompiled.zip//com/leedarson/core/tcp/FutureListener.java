package com.leedarson.core.tcp;

import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;

public abstract class FutureListener implements ChannelFutureListener {
   public void operationComplete(ChannelFuture future) throws Exception {
      if (future.isSuccess()) {
         this.success();
      } else {
         this.error();
      }

   }

   public abstract void success();

   public abstract void error();
}
