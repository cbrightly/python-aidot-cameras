package com.leedarson.core.tcp;

import android.util.Log;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import java.util.Random;

public class INettyClientHandler extends SimpleChannelInboundHandler<Object> {
   private static final String TAG = INettyClientHandler.class.getName();
   private INettyListener listener;
   private short cmd;
   private short subCmd;
   private int cmdParam;

   public INettyClientHandler(INettyListener listener, short cmd, short subCmd, int cmdParam) {
      this.listener = listener;
      this.cmd = cmd;
      this.subCmd = subCmd;
      this.cmdParam = cmdParam;
   }

   public void channelActive(ChannelHandlerContext ctx) throws Exception {
      this.listener.onServiceStatusConnectChanged(1);
   }

   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
      this.listener.onServiceStatusConnectChanged(2);
   }

   public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
      super.userEventTriggered(ctx, evt);
      if (evt instanceof IdleStateEvent) {
         IdleStateEvent event = (IdleStateEvent)evt;
         if (event.state() == IdleState.WRITER_IDLE) {
            Log.e(TAG, "userEventTriggered:WRITER_IDLE ");
            RecordVideoHeader head = new RecordVideoHeader();
            head.setVersion(256);
            head.setSequence((new Random()).nextInt());
            head.setCmd(this.cmd);
            head.setSubCmd(this.subCmd);
            head.setCmdParam(this.cmdParam);
            head.setTimeStamp(System.currentTimeMillis());
            head.setContext(1005);
            head.setEncodeType(1);
            head.setResult(4);
            head.setReserve(2);
            RecordVideoMessage message = new RecordVideoMessage(head);
            ctx.channel().writeAndFlush(message);
         }
      }

   }

   protected void channelRead0(ChannelHandlerContext channelHandlerContext, Object o) throws Exception {
      Channel incoming = channelHandlerContext.channel();
      if (o instanceof RecordVideoMessage) {
         RecordVideoMessage msg = (RecordVideoMessage)o;
         Log.e("channelRead0", "Server->Client:" + incoming.remoteAddress() + " cmd:" + msg.getHeader().getCmd());
         if (msg.getHeader().getCmd() != 262) {
            new String(msg.getPayload(), "UTF-8");
            this.listener.onMessageResponse(msg);
         }
      }

   }
}
