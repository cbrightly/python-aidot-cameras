package com.leedarson.core.tcp;

public class RecordVideoHeader {
   private int cmd;
   private int cmdParam;
   private int context;
   private int encodeType;
   private int payloadlen;
   private int reserve;
   private int result;
   private int sequence;
   private int subCmd;
   private long timeStamp;
   private int version;

   public int getVersion() {
      return this.version;
   }

   public void setVersion(int version) {
      this.version = version;
   }

   public int getSequence() {
      return this.sequence;
   }

   public void setSequence(int sequence) {
      this.sequence = sequence;
   }

   public int getCmd() {
      return this.cmd;
   }

   public void setCmd(int cmd) {
      this.cmd = cmd;
   }

   public int getSubCmd() {
      return this.subCmd;
   }

   public void setSubCmd(int subCmd) {
      this.subCmd = subCmd;
   }

   public int getCmdParam() {
      return this.cmdParam;
   }

   public void setCmdParam(int cmdParam) {
      this.cmdParam = cmdParam;
   }

   public int getPayloadlen() {
      return this.payloadlen;
   }

   public void setPayloadlen(int payloadlen) {
      this.payloadlen = payloadlen;
   }

   public long getTimeStamp() {
      return this.timeStamp;
   }

   public void setTimeStamp(long timeStamp) {
      this.timeStamp = timeStamp;
   }

   public int getContext() {
      return this.context;
   }

   public void setContext(int context) {
      this.context = context;
   }

   public int getEncodeType() {
      return this.encodeType;
   }

   public void setEncodeType(int encodeType) {
      this.encodeType = encodeType;
   }

   public int getResult() {
      return this.result;
   }

   public void setResult(int result) {
      this.result = result;
   }

   public int getReserve() {
      return this.reserve;
   }

   public void setReserve(int reserve) {
      this.reserve = reserve;
   }

   public String toString() {
      return "RecordVideoHeader{version=" + this.version + ", sequence=" + this.sequence + ", cmd=" + this.cmd + ", subCmd=" + this.subCmd + ", cmdParam=" + this.cmdParam + ", payloadlen=" + this.payloadlen + ", timeStamp=" + this.timeStamp + ", context=" + this.context + ", encodeType=" + this.encodeType + ", result=" + this.result + ", reserve=" + this.reserve + '}';
   }
}
