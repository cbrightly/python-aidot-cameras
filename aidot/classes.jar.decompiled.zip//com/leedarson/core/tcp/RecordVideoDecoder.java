package com.leedarson.core.tcp;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;

public class RecordVideoDecoder extends LengthFieldBasedFrameDecoder {
   private static final int HEADER_SIZE = 18;

   public RecordVideoDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength, int lengthAdjustment, int initialBytesToStrip) {
      super(maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip);
   }

   public RecordVideoDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength, int lengthAdjustment, int initialBytesToStrip, boolean failFast) {
      super(maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip, failFast);
   }

   protected RecordVideoMessage decode(ChannelHandlerContext ctx, ByteBuf in2) throws Exception {
      ByteBuf in = (ByteBuf)super.decode(ctx, in2);
      if (in == null) {
         return null;
      } else if (in.readableBytes() < 18) {
         return null;
      } else {
         RecordVideoHeader head = new RecordVideoHeader();
         head.setVersion(in.readShort());
         head.setSequence(in.readInt());
         head.setCmd(in.readShort());
         head.setSubCmd(in.readShort());
         head.setCmdParam(in.readInt());
         int payloadLen = in.readInt();
         if (in.readableBytes() < payloadLen + 19) {
            return null;
         } else {
            head.setTimeStamp(in.readLong());
            head.setContext(in.readInt());
            head.setEncodeType(in.readByte());
            head.setResult(in.readShort());
            head.setReserve(in.readInt());
            ByteBuf buf = in.readBytes(payloadLen);
            byte[] req = new byte[buf.readableBytes()];
            buf.readBytes(req);
            RecordVideoMessage message = new RecordVideoMessage(head, req);
            return message;
         }
      }
   }
}
