package com.leedarson.core.tcp;

public interface AppCmd {
   int HEARTBEAT_REQ = 261;
   int HEARTBEAT_RES = 262;
   int LOGIN_REQ = 257;
   int LOGIN_RES = 258;
   int LOGOUT_REQ = 259;
   int LOGOUT_RES = 260;
   int SEND_VIDEO_STREAM_REQ = 263;
   int SEND_VIDEO_STREAM_RES = 264;
}
