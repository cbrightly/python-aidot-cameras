package com.leedarson.core.tcp;

public class RecordVideoMessage {
   private RecordVideoHeader header;
   private byte[] payload;

   public RecordVideoMessage(RecordVideoHeader header) {
      this.header = header;
   }

   public RecordVideoMessage(RecordVideoHeader header, byte[] payload) {
      header.setPayloadlen(payload.length);
      this.header = header;
      this.payload = payload;
   }

   public RecordVideoHeader getHeader() {
      return this.header;
   }

   public byte[] getPayload() {
      return this.payload;
   }

   public String toString() {
      return "RecordVideoMessage [header=" + this.header + "]";
   }
}
