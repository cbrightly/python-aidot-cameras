package com.leedarson.core.tcp;

public interface INettyListener {
   byte STATUS_CONNECT_SUCCESS = 1;
   byte STATUS_CONNECT_CLOSED = 2;
   byte STATUS_CONNECT_ERROR = 0;

   void onMessageResponse(RecordVideoMessage var1);

   void onServiceStatusConnectChanged(int var1);
}
