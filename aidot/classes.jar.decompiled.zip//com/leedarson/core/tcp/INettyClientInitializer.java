package com.leedarson.core.tcp;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;

public class INettyClientInitializer extends ChannelInitializer<SocketChannel> {
   private INettyListener listener;
   private static final int MAX_FRAME_LENGTH = 1048576;
   private static final int LENGTH_FIELD_LENGTH = 4;
   private static final int LENGTH_FIELD_OFFSET = 14;
   private static final int LENGTH_ADJUSTMENT = 19;
   private static final int INITIAL_BYTES_TO_STRIP = 0;
   private int heartbeat = 15;
   private short cmd;
   private short subCmd;
   private int cmdParam;

   public INettyClientInitializer(INettyListener listener, int heartbeat, short cmd, short subCmd, int cmdParam) {
      if (listener == null) {
         throw new IllegalArgumentException("listener == null ");
      } else {
         this.listener = listener;
         this.heartbeat = heartbeat;
         this.cmd = cmd;
         this.subCmd = subCmd;
         this.cmdParam = cmdParam;
      }
   }

   protected void initChannel(SocketChannel ch) throws Exception {
      ChannelPipeline pipeline = ch.pipeline();
      pipeline.addLast(new ChannelHandler[]{new LoggingHandler(LogLevel.INFO)});
      pipeline.addLast("IdleStateHandler", new IdleStateHandler(0, this.heartbeat, 0));
      pipeline.addLast("decoder", new RecordVideoDecoder(1048576, 14, 4, 19, 0));
      pipeline.addLast("encoder", RecordVideoEncoder.INSTANCE);
      pipeline.addLast(new ChannelHandler[]{new INettyClientHandler(this.listener, this.cmd, this.subCmd, this.cmdParam)});
   }
}
