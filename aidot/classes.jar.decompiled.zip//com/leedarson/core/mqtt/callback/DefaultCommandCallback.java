package com.leedarson.core.mqtt.callback;

public class DefaultCommandCallback<T> implements CommandCallback<T> {
   public void onSuccess(T response, boolean isMQTT) {
   }

   public void onSuccess(String service, String method, T response, boolean isMQTT) {
   }

   public void onFailure(int code, String errorStr) {
   }

   public void onException(Throwable throwable) {
   }
}
