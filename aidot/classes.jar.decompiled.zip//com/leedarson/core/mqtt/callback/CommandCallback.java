package com.leedarson.core.mqtt.callback;

public interface CommandCallback<T> {
   void onSuccess(T var1, boolean var2);

   void onFailure(int var1, String var2);

   void onException(Throwable var1);
}
