package com.leedarson.core.mqtt;

public class ObservableMessage {
   public String mService;
   public String mMethod;
   public Object mResponse;
   public boolean mIsMQTT;
   public int mCode;
   public String mErrorStr;
   public int flag = 0;
}
