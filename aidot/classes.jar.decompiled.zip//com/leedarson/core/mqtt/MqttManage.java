package com.leedarson.core.mqtt;

import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import com.leedarson.core.mqtt.callback.CommandCallback;
import com.leedarson.core.mqtt.callback.DefaultCommandCallback;
import com.leedarson.mqtt.listener.IMqttListener;
import com.leedarson.mqtt.pahomqtt.LDSMqttManager;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class MqttManage {
   public static ArrayMap callbacks = new ArrayMap();
   private static final int TIMEOUT = 30;
   private final String TAG;

   private MqttManage() {
      this.TAG = MqttManage.class.getSimpleName();
   }

   public static MqttManage getInstance() {
      return MqttManage.SigletonHolder.INSTANCE;
   }

   public void sendMQTTCommand(final String topic, final String message, final String requestId, final CommandCallback callback) {
      Observable.create(new ObservableOnSubscribe<ObservableMessage>() {
         public void subscribe(@NonNull final ObservableEmitter<ObservableMessage> e) throws Exception {
            final ObservableMessage observableMessage = new ObservableMessage();
            if (!e.isDisposed()) {
               LDSMqttManager.getInstance().publish(topic, message, (IMqttListener)null);
               DefaultCommandCallback defaultCommandCallback = new DefaultCommandCallback() {
                  public void onSuccess(String service, String method, Object response, boolean isMQTT) {
                     super.onSuccess(service, method, response, isMQTT);
                     observableMessage.flag = 0;
                     observableMessage.mService = service;
                     observableMessage.mMethod = method;
                     observableMessage.mResponse = response;
                     observableMessage.mIsMQTT = isMQTT;
                     e.onNext(observableMessage);
                     e.onComplete();
                  }

                  public void onSuccess(Object response, boolean isMQTT) {
                     super.onSuccess(response, isMQTT);
                     observableMessage.flag = 0;
                     observableMessage.mResponse = response;
                     observableMessage.mIsMQTT = isMQTT;
                     e.onNext(observableMessage);
                     e.onComplete();
                  }

                  public void onFailure(int code, String errorStr) {
                     super.onFailure(code, errorStr);
                     observableMessage.flag = -1;
                     observableMessage.mCode = code;
                     observableMessage.mErrorStr = errorStr;
                     e.onNext(observableMessage);
                     e.onComplete();
                  }

                  public void onException(Throwable throwable) {
                     super.onException(throwable);
                     observableMessage.flag = -1;
                     observableMessage.mCode = -1;
                     e.onNext(observableMessage);
                     e.onComplete();
                  }
               };
               MqttManage.callbacks.put(requestId, defaultCommandCallback);
            }

         }
      }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).timeout(30L, TimeUnit.SECONDS).subscribe(new Observer<ObservableMessage>() {
         public void onSubscribe(@NonNull Disposable d) {
         }

         public void onNext(@NonNull ObservableMessage message1) {
            switch(message1.flag) {
            case -1:
               callback.onFailure(message1.mCode, "Mqtt publish Fail!");
               break;
            case 0:
               callback.onSuccess(message1.mResponse, message1.mIsMQTT);
               break;
            case 1:
               callback.onSuccess(message1.mResponse, message1.mIsMQTT);
            }

         }

         public void onError(@NonNull Throwable e) {
            if (e instanceof TimeoutException) {
               callback.onFailure(-2, "Mqtt request time out");
            } else {
               callback.onFailure(-3, (String)null);
            }

         }

         public void onComplete() {
         }
      });
   }

   // $FF: synthetic method
   MqttManage(Object x0) {
      this();
   }

   private static class SigletonHolder {
      private static MqttManage INSTANCE = new MqttManage();
   }
}
