package com.leedarson.sdk.bean;

public class AuthInfo {
   private String associatedAccount;
   private String accessToken;
   private String refreshToken;
   private Object userUuid;
   private String mqqtPwd;
   private int expires;

   public String getAssociatedAccount() {
      return this.associatedAccount;
   }

   public void setAssociatedAccount(String associatedAccount) {
      this.associatedAccount = associatedAccount;
   }

   public String getAccessToken() {
      return this.accessToken;
   }

   public void setAccessToken(String accessToken) {
      this.accessToken = accessToken;
   }

   public String getRefreshToken() {
      return this.refreshToken;
   }

   public void setRefreshToken(String refreshToken) {
      this.refreshToken = refreshToken;
   }

   public Object getUserUuid() {
      return this.userUuid;
   }

   public void setUserUuid(Object userUuid) {
      this.userUuid = userUuid;
   }

   public String getMqqtPwd() {
      return this.mqqtPwd;
   }

   public void setMqqtPwd(String mqqtPwd) {
      this.mqqtPwd = mqqtPwd;
   }

   public int getExpires() {
      return this.expires;
   }

   public void setExpires(int expires) {
      this.expires = expires;
   }
}
