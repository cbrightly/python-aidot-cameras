package com.leedarson.sdk.bean;

public class CloudRecord {
   private long sta;
   private long end;

   public long getSta() {
      return this.sta;
   }

   public void setSta(long sta) {
      this.sta = sta;
   }

   public long getEnd() {
      return this.end;
   }

   public void setEnd(long end) {
      this.end = end;
   }
}
