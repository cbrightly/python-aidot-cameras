package com.leedarson.sdk.bean;

public class LDSDeviceInfo {
   private String devId;
   private String productId;
   private String name;
   private boolean online;

   public String getDevId() {
      return this.devId;
   }

   public void setDevId(String devId) {
      this.devId = devId;
   }

   public String getProductId() {
      return this.productId;
   }

   public void setProductId(String productId) {
      this.productId = productId;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public boolean isOnline() {
      return this.online;
   }

   public void setOnline(boolean online) {
      this.online = online;
   }
}
