package com.leedarson.sdk.bean;

public class ServerConfig {
   private long reqTimestamp;
   private long resTimestamp;
   private String ntpServerUrl;
   private String mqttServerUrl;
   private int heartbeat;
   private String httpHeader;
   private String ip;
   private int uniqueMsgId;

   public long getReqTimestamp() {
      return this.reqTimestamp;
   }

   public void setReqTimestamp(long reqTimestamp) {
      this.reqTimestamp = reqTimestamp;
   }

   public long getResTimestamp() {
      return this.resTimestamp;
   }

   public void setResTimestamp(long resTimestamp) {
      this.resTimestamp = resTimestamp;
   }

   public String getNtpServerUrl() {
      return this.ntpServerUrl;
   }

   public void setNtpServerUrl(String ntpServerUrl) {
      this.ntpServerUrl = ntpServerUrl;
   }

   public String getMqttServerUrl() {
      return this.mqttServerUrl;
   }

   public void setMqttServerUrl(String mqttServerUrl) {
      this.mqttServerUrl = mqttServerUrl;
   }

   public int getHeartbeat() {
      return this.heartbeat;
   }

   public void setHeartbeat(int heartbeat) {
      this.heartbeat = heartbeat;
   }

   public String getHttpHeader() {
      return this.httpHeader;
   }

   public void setHttpHeader(String httpHeader) {
      this.httpHeader = httpHeader;
   }

   public String getIp() {
      return this.ip;
   }

   public void setIp(String ip) {
      this.ip = ip;
   }

   public int getUniqueMsgId() {
      return this.uniqueMsgId;
   }

   public void setUniqueMsgId(int uniqueMsgId) {
      this.uniqueMsgId = uniqueMsgId;
   }
}
