package com.leedarson.sdk;

import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.leedarson.core.Utils.GsonUtils;
import com.leedarson.core.Utils.Utils;
import com.leedarson.core.bean.GetPlaybackServerInfoResp;
import com.leedarson.core.bean.GetRecordResp;
import com.leedarson.core.bean.GetTaskIdResp;
import com.leedarson.core.bean.getOtaVersionResp;
import com.leedarson.core.http.HttpManager;
import com.leedarson.core.http.bean.DevListResp;
import com.leedarson.core.http.exception.ApiException;
import com.leedarson.core.http.observer.HttpRxObserver;
import com.leedarson.core.mqtt.MqttManage;
import com.leedarson.core.mqtt.callback.CommandCallback;
import com.leedarson.core.mqtt.callback.DefaultCommandCallback;
import com.leedarson.core.tcp.INettyListener;
import com.leedarson.core.tcp.INettyManager;
import com.leedarson.core.tcp.RecordVideoHeader;
import com.leedarson.core.tcp.RecordVideoMessage;
import com.leedarson.core.udp.UdpManager;
import com.leedarson.core.udp.bean.BindInfoResp;
import com.leedarson.core.udp.bean.SetWifiResp;
import com.leedarson.core.udp.bean.UdpDiscoveryResp;
import com.leedarson.core.udp.listener.UdpResponseListener;
import com.leedarson.mqtt.listener.IMqttListener;
import com.leedarson.mqtt.listener.LDSMqttListener;
import com.leedarson.mqtt.pahomqtt.LDSMqttManager;
import com.leedarson.sdk.bean.AuthInfo;
import com.leedarson.sdk.bean.CloudRecord;
import com.leedarson.sdk.bean.LDSDeviceInfo;
import com.leedarson.sdk.bean.ServerConfig;
import com.leedarson.sdk.listener.BindDeviceListener;
import com.leedarson.sdk.listener.CheckUpdateListListener;
import com.leedarson.sdk.listener.CreatePlayerListener;
import com.leedarson.sdk.listener.GetDeviceListListener;
import com.leedarson.sdk.listener.GetRecordListListener;
import com.leedarson.sdk.listener.UnbindDeviceListener;
import com.leedarson.sdk.player.LDSPlayer;
import io.reactivex.disposables.Disposable;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONException;
import org.json.JSONObject;

public class LDSOpenSDK {
   private static final String TAG = "LDSOpenSDK";
   private static final String BASE_URL = "https://test-smarthome.arnoo.com:443";
   private static final String HTTP_HEADER = "{\"terminal\":\"thirdPlatFormUser\",\"active-language\":\"zh_CN\"}";
   private static final String HTTP_VERSION = "1.0.1";
   private String mqttUrl = "";
   private AuthInfo authInfo;
   private String appKey;
   private Context context;
   private boolean isMqttConnected = false;
   public String unbindDevid;
   public String productId;
   public String homeId = "";
   ExecutorService newCachedThreadPool = Executors.newCachedThreadPool();
   private boolean bindEnd = false;
   private BindDeviceListener bindListener;
   private HashMap<String, String> p2ps = new HashMap();
   private LDSMqttListener listener = new LDSMqttListener() {
      public void initLocalSuccess() {
         LDSOpenSDK.this.isMqttConnected = false;
         Log.e("LDSOpenSDK", "initLocalSuccess: " + LDSOpenSDK.this.mqttUrl);
         if (!"".equals(LDSOpenSDK.this.mqttUrl)) {
            LDSMqttManager.getInstance().connect(LDSOpenSDK.this.mqttUrl);
         }

      }

      public void initLocalFail() {
         Log.e("LDSOpenSDK", "initLocalFail: ");
      }

      public void onLocalMqttStateChanged(int code, String errorStr) {
         Log.e("LDSOpenSDK", "onLocalMqttStateChanged: " + code);
         if (code == 1 && !LDSOpenSDK.this.isMqttConnected) {
            LDSOpenSDK.this.isMqttConnected = true;
            LDSMqttManager.getInstance().subscribe(String.format("iot/v1/c/%s/#", LDSOpenSDK.this.authInfo != null ? LDSOpenSDK.this.authInfo.getAssociatedAccount() : ""), new IMqttListener() {
               public void onSuccess() {
                  Log.e("LDSOpenSDK", "subscribe user onSuccess: ");
               }

               public void onFailure(Throwable exception) {
               }
            });
            LDSMqttManager.getInstance().subscribe(String.format("iot/v1/cb/%s/#", LDSOpenSDK.this.unbindDevid), new IMqttListener() {
               public void onSuccess() {
                  Log.e("LDSOpenSDK", "subscribe device onSuccess: ");
               }

               public void onFailure(Throwable exception) {
                  Log.e("LDSOpenSDK", "subscribe device onFailure: ");
               }
            });
         } else {
            LDSOpenSDK.this.isMqttConnected = false;
         }

      }

      public void onLocalMessageArrived(String topic, String message) {
         Log.e("LDSOpenSDK", "onLocalMessageArrived  topic  = " + topic + "  message = " + message);
         String requestId = (String)GsonUtils.getJsonMap(message).get("seq");
         JSONObject objMsg = new JSONObject();

         try {
            objMsg.put("topic", topic);
         } catch (JSONException var9) {
            var9.printStackTrace();
         }

         try {
            JSONObject jsonStr = new JSONObject(message);
            objMsg.put("message", jsonStr);
         } catch (Exception var8) {
            try {
               objMsg.put("message", message);
            } catch (JSONException var7) {
               var7.printStackTrace();
            }
         }

         if (!TextUtils.isEmpty(requestId)) {
            DefaultCommandCallback callback = (DefaultCommandCallback)MqttManage.callbacks.get(requestId);
            if (callback != null) {
               callback.onSuccess(message, true);
            }
         }

      }
   };
   private boolean isStopRecord = true;
   private boolean isPauseRecord = false;
   private LDSPlayer player;
   private long staTime;
   private String serverIp;
   private int serverPort;
   private int heartbeat;
   private int taskId;
   private INettyListener tcpListener = new INettyListener() {
      public void onMessageResponse(RecordVideoMessage message) {
         int seq = message.getHeader().getSequence();
         com.leedarson.core.tcp.callback.DefaultCommandCallback callback = (com.leedarson.core.tcp.callback.DefaultCommandCallback)INettyManager.callbacks.get(seq);
         if (callback != null) {
            callback.onSuccess(message, false);
            INettyManager.callbacks.remove(seq);
         } else {
            Log.e("LDSOpenSDK", "onMessageResponse:no callback");
         }

      }

      public void onServiceStatusConnectChanged(int statusCode) {
         Log.e("LDSOpenSDK", "onServiceStatusConnectChanged: --" + statusCode);
         if (statusCode == 1) {
            LDSOpenSDK.this.openTaskChannel();
         } else if (statusCode != 2 && statusCode == 0) {
         }

      }
   };

   public static LDSOpenSDK getInstance() {
      return LDSOpenSDK.SingletonHolder.INSTANCE;
   }

   public void setAuthInfo(AuthInfo authInfo) {
      this.authInfo = authInfo;
      this.getServerConfig(this.context);
   }

   public void setAppKey(Context context, String appKey) {
      this.context = context;
      this.appKey = appKey;
   }

   public void createPlayer(String devId, final CreatePlayerListener listener) {
      String p2pId = (String)this.p2ps.get(devId);
      if (TextUtils.isEmpty(p2pId)) {
         String token = this.authInfo != null ? this.authInfo.getAccessToken() : "";
         this.getP2pId(devId, token, this.appKey, new HttpRxObserver<String>() {
            protected void onStart(Disposable d) {
            }

            protected void onError(ApiException e) {
               Log.e("LDSOpenSDK", "onError: " + e.getCode());
               if (listener != null) {
                  listener.onError(-1, "");
               }

            }

            protected void onSuccess(String response) {
               Log.e("LDSOpenSDK", "getP2pId onSuccess: " + response);
               JsonObject jsonObject = (JsonObject)(new JsonParser()).parse(response);
               String p2pId = jsonObject.get("data").getAsString();
               LDSOpenSDK.this.createPlayer(p2pId, "admin", "admin123", listener);
            }
         });
      } else {
         this.createPlayer(p2pId, "admin", "admin123", listener);
      }

   }

   public LDSPlayer createPlayer() {
      LDSPlayer player = new LDSPlayer();
      int ret = player.initPlayer();
      player.setLogLevel(0);
      player.createPlayer();
      return player;
   }

   private void createPlayer(String p2pId, String account, String pwd, CreatePlayerListener listener) {
      if (listener != null) {
         LDSPlayer player = new LDSPlayer(p2pId, account, pwd);
         int ret = player.init();
         player.setLogLevel(0);
         player.createPlayer();
         listener.onSuccess(player);
      }

   }

   public void getDeviceList(final GetDeviceListListener listener) {
      String token = this.authInfo != null ? this.authInfo.getAccessToken() : "";
      final JSONObject headerJ = null;

      try {
         headerJ = new JSONObject("{\"terminal\":\"thirdPlatFormUser\",\"active-language\":\"zh_CN\"}");
         headerJ.put("access-token", token);
         headerJ.put("token", token);
         headerJ.put("appKey", this.appKey);
      } catch (JSONException var6) {
         var6.printStackTrace();
      }

      String homePostMsg = "{\"cache\":true,\"pageSize\":100,\"offset\":0}";
      HttpManager.getInstance().requestHttpPost("https://test-smarthome.arnoo.com:443/home/getHomeList", headerJ != null ? headerJ.toString() : "", homePostMsg, new HttpRxObserver<String>() {
         protected void onStart(Disposable d) {
         }

         protected void onError(ApiException e) {
            Log.e("LDSOpenSDK", "getHomeList onError: " + e.getCode() + "--" + e.getMsg());
            if (listener != null) {
               listener.onError(e.getCode(), e.getMsg());
            }

         }

         protected void onSuccess(String response) {
            Log.e("LDSOpenSDK", "getHomeList onSuccess: " + response);
            JsonObject jsonObject = (JsonObject)(new JsonParser()).parse(response);
            JsonObject dataObj = jsonObject.getAsJsonObject("data");
            JsonArray homesArr = dataObj.getAsJsonArray("homes");

            for(int i = 0; i < homesArr.size(); ++i) {
               JsonObject homeObj = homesArr.get(i).getAsJsonObject();
               if (homeObj.get("defaultHome").getAsInt() == 1) {
                  LDSOpenSDK.this.homeId = homeObj.get("homeId").getAsString();
               }
            }

            JSONObject getDevObj = new JSONObject();

            try {
               getDevObj.put("homeId", LDSOpenSDK.this.homeId);
            } catch (JSONException var7) {
               var7.printStackTrace();
            }

            HttpManager.getInstance().requestHttpGet("https://test-smarthome.arnoo.com:443/deviceController/getDevList", headerJ != null ? headerJ.toString() : "", getDevObj.toString(), new HttpRxObserver<String>() {
               protected void onStart(Disposable d) {
               }

               protected void onError(ApiException e) {
                  Log.e("LDSOpenSDK", "getDevList onError: " + e.getCode());
                  if (listener != null) {
                     listener.onError(e.getCode(), e.getMsg());
                  }

               }

               protected void onSuccess(String response) {
                  Log.e("LDSOpenSDK", "getDevList onSuccess: " + response);
                  Gson gson = new Gson();
                  DevListResp resp = (DevListResp)gson.fromJson(response, DevListResp.class);
                  if (resp != null && resp.getCode() == 200) {
                     List<LDSDeviceInfo> devices = new ArrayList();
                     Log.e("LDSOpenSDK", "dev size: " + resp.getData().getDev().size());

                     for(int i = 0; i < resp.getData().getDev().size(); ++i) {
                        LDSDeviceInfo deviceInfo = new LDSDeviceInfo();
                        deviceInfo.setDevId(((DevListResp.DataBean.DevBean)resp.getData().getDev().get(i)).getDevId());
                        deviceInfo.setName(((DevListResp.DataBean.DevBean)resp.getData().getDev().get(i)).getName());
                        deviceInfo.setOnline(((DevListResp.DataBean.DevBean)resp.getData().getDev().get(i)).isOnline());
                        deviceInfo.setProductId(((DevListResp.DataBean.DevBean)resp.getData().getDev().get(i)).getProductId());
                        devices.add(deviceInfo);
                        LDSOpenSDK.this.unbindDevid = ((DevListResp.DataBean.DevBean)resp.getData().getDev().get(i)).getDevId();
                        LDSOpenSDK.this.productId = ((DevListResp.DataBean.DevBean)resp.getData().getDev().get(i)).getProductId();
                     }

                     if (listener != null) {
                        listener.onSuccess(devices);
                     }
                  }

               }
            });
         }
      });
   }

   private void getServerConfig(final Context context) {
      JSONObject dataj = new JSONObject();
      final String uid = this.authInfo != null ? this.authInfo.getAssociatedAccount() : "";
      final String mqttPwd = this.authInfo != null ? this.authInfo.getMqqtPwd() : "";

      try {
         dataj.put("version", "1.0.1");
         dataj.put("clientId", "app-" + uid);
      } catch (JSONException var6) {
         var6.printStackTrace();
      }

      HttpManager.getInstance().requestHttpGet("https://test-smarthome.arnoo.com:443/commonController/getServerUrlConfig", "{\"terminal\":\"thirdPlatFormUser\",\"active-language\":\"zh_CN\"}", dataj.toString(), new HttpRxObserver<String>() {
         protected void onStart(Disposable d) {
         }

         protected void onError(ApiException e) {
            Log.e("LDSOpenSDK", "onError: " + e.getCode());
         }

         protected void onSuccess(String response) {
            Log.e("LDSOpenSDK", "onSuccess: " + response);
            JsonObject jsonObject = (JsonObject)(new JsonParser()).parse(response);
            JsonObject dataObj = jsonObject.getAsJsonObject("data");
            Gson gson = new Gson();
            ServerConfig config = (ServerConfig)gson.fromJson(dataObj.toString(), ServerConfig.class);
            if (config != null) {
               LDSOpenSDK.this.mqttUrl = "wss://" + config.getMqttServerUrl();
               LDSMqttManager.getInstance().setListener(LDSOpenSDK.this.listener);
               JSONObject willObj = new JSONObject();

               try {
                  willObj.put("service", "user");
                  willObj.put("method", "disconnect");
                  willObj.put("seq", "089059874");
                  willObj.put("srcAddr", String.format("0.%s", uid));
                  JSONObject payObj = new JSONObject();
                  long time = System.currentTimeMillis();
                  SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                  Date d1 = new Date(time);
                  String t1 = format.format(d1);
                  payObj.put("timestamp", t1);
                  payObj.put("uniqueMsgId", 0);
                  willObj.put("payload", payObj);
               } catch (JSONException var13) {
                  var13.printStackTrace();
               }

               LDSMqttManager.getInstance().initCredentials(context, uid, mqttPwd, "app-" + uid, true, String.format("iot/v1/cb/%s/user/disconnect", uid), willObj.toString());
            }

         }
      });
   }

   private void getP2pId(String deviceid, String token, String appKey, HttpRxObserver observer) {
      JSONObject headerJ = null;

      try {
         headerJ = new JSONObject("{\"terminal\":\"thirdPlatFormUser\",\"active-language\":\"zh_CN\"}");
         headerJ.put("access-token", token);
         headerJ.put("token", token);
         headerJ.put("appKey", appKey);
      } catch (JSONException var9) {
         var9.printStackTrace();
      }

      JSONObject dataj = new JSONObject();

      try {
         dataj.put("deviceId", deviceid);
      } catch (JSONException var8) {
         var8.printStackTrace();
      }

      HttpManager.getInstance().requestHttpPostForm("https://test-smarthome.arnoo.com:443/deviceController/getP2pId", headerJ.toString(), dataj.toString(), observer);
   }

   public void bind(final String ssid, final String pwd, final BindDeviceListener listener) {
      this.bindListener = listener;
      UdpManager.getInstance().send("", 6666, "{\"service\":\"device\",\"method\":\"devDiscoveryReq\",\"payload\":{\"timestamp\":\"1560220303071\"},\"seq\":\"220303074\",\"srcAddr\":\"d71ea110a37345bd95896f17594d86c4\"}", false, new UdpResponseListener() {
         public void onResponse(String message) {
            Log.e("LDSOpenSDK", "discovery onResponse: " + message);
            final Gson gson = new Gson();
            UdpDiscoveryResp resp = (UdpDiscoveryResp)gson.fromJson(message, UdpDiscoveryResp.class);
            if (resp != null && resp.getAck().getCode() == 200) {
               JSONObject dataObj = new JSONObject();
               JSONObject pLoad = new JSONObject();

               try {
                  dataObj.put("service", "device");
                  dataObj.put("method", "setBindInfoReq");
                  dataObj.put("seq", "220303131");
                  dataObj.put("srcAddr", LDSOpenSDK.this.authInfo != null ? LDSOpenSDK.this.authInfo.getAssociatedAccount() : "");
                  TimeZone tz = TimeZone.getDefault();
                  pLoad.put("timeZone", tz.getDisplayName(false, 0));
                  pLoad.put("area", tz.getID());
                  pLoad.put("timestamp", "" + System.currentTimeMillis());
                  pLoad.put("reconfigWifi", 0);
                  pLoad.put("userId", LDSOpenSDK.this.authInfo != null ? LDSOpenSDK.this.authInfo.getAssociatedAccount() : "");
                  dataObj.put("payload", pLoad);
               } catch (JSONException var7) {
                  var7.printStackTrace();
               }

               UdpManager.getInstance().send(resp.getPayload().getIp(), 6667, dataObj.toString(), false, new UdpResponseListener() {
                  public void onResponse(String message) {
                     Log.e("LDSOpenSDK", "setBindInfoReq onResponse: " + message);
                     final BindInfoResp resp = (BindInfoResp)gson.fromJson(message, BindInfoResp.class);
                     if (resp != null && resp.getAck().getCode() == 200) {
                        JSONObject dataObj = new JSONObject();
                        JSONObject pLoad = new JSONObject();

                        try {
                           dataObj.put("service", "device");
                           dataObj.put("method", "setWifiReq");
                           dataObj.put("seq", "220303130");
                           dataObj.put("srcAddr", LDSOpenSDK.this.authInfo != null ? LDSOpenSDK.this.authInfo.getAssociatedAccount() : "");
                           pLoad.put("ssid", ssid);
                           pLoad.put("password", pwd);
                           pLoad.put("secret", "WPA2");
                           dataObj.put("payload", pLoad);
                        } catch (Exception var6) {
                           var6.printStackTrace();
                        }

                        UdpManager.getInstance().send(resp.getPayload().getIp(), 6667, dataObj.toString(), false, new UdpResponseListener() {
                           public void onResponse(String message) {
                              Log.e("LDSOpenSDK", "setWifiReq onResponse: " + message);
                              SetWifiResp resp1 = (SetWifiResp)gson.fromJson(message, SetWifiResp.class);
                              if (resp1 != null && resp1.getAck().getCode() == 200) {
                                 LDSOpenSDK.this.bindEnd = false;
                                 (LDSOpenSDK.this.new getBindTask()).executeOnExecutor(LDSOpenSDK.this.newCachedThreadPool, new String[]{resp1.getPayload().getDevId()});
                              } else if (listener != null) {
                                 listener.onError(resp != null ? resp.getAck().getCode() : -3, "");
                              }

                           }

                           public void onError(int code, String msg) {
                              if (listener != null) {
                                 listener.onError(-3, "");
                              }

                           }
                        });
                     }

                  }

                  public void onError(int code, String msg) {
                     if (listener != null) {
                        listener.onError(-2, "");
                     }

                  }
               });
            } else if (listener != null) {
               listener.onError(resp != null ? resp.getAck().getCode() : -1, "can't find device");
            }

         }

         public void onError(int code, String msg) {
            if (listener != null) {
               listener.onError(-1, "can't find device");
            }

         }
      });
   }

   private void getBindResult(String devid) {
      JSONObject headerJ = null;

      try {
         headerJ = new JSONObject("{\"terminal\":\"thirdPlatFormUser\",\"active-language\":\"zh_CN\"}");
         headerJ.put("access-token", this.authInfo.getAccessToken());
         headerJ.put("token", this.authInfo.getAccessToken());
         headerJ.put("appKey", this.appKey);
      } catch (JSONException var6) {
         var6.printStackTrace();
      }

      JSONObject dataj = new JSONObject();

      try {
         dataj.put("userId", this.authInfo.getAssociatedAccount());
         dataj.put("devId", devid);
      } catch (JSONException var5) {
         var5.printStackTrace();
      }

      HttpManager.getInstance().requestHttpGet("https://test-smarthome.arnoo.com:443/device/getDevBindNotif", headerJ.toString(), dataj.toString(), new HttpRxObserver<String>() {
         protected void onStart(Disposable d) {
         }

         protected void onError(ApiException e) {
            Log.e("LDSOpenSDK", "getDevBindNotif onError: " + e.getCode() + " " + e.getMsg());
         }

         protected void onSuccess(String response) {
            Log.e("LDSOpenSDK", "getDevBindNotif onSuccess: " + response);
            LDSOpenSDK.this.bindEnd = true;
            if (LDSOpenSDK.this.bindListener != null) {
               LDSOpenSDK.this.bindListener.onSuccess();
               LDSOpenSDK.this.bindListener = null;
            }

         }
      });
   }

   public void unBind(String devId, final UnbindDeviceListener listener) {
      String seq = (new Random()).nextInt() + "";
      String topic = String.format("iot/v1/s/%s/device/devUnbindReq", this.authInfo != null ? this.authInfo.getAssociatedAccount() : "");
      String userid = this.authInfo != null ? this.authInfo.getAssociatedAccount() : "";
      JSONObject dataObj = new JSONObject();
      JSONObject pLoad = new JSONObject();

      try {
         dataObj.put("service", "device");
         dataObj.put("method", "devUnbindReq");
         dataObj.put("seq", seq);
         dataObj.put("srcAddr", String.format("0.%s", userid));
         pLoad.put("unbindDevId", devId);
         pLoad.put("unbindUserId", userid);
         pLoad.put("userId", userid);
         pLoad.put("resetFlag", 0);
         dataObj.put("payload", pLoad);
      } catch (Exception var9) {
         var9.printStackTrace();
      }

      MqttManage.getInstance().sendMQTTCommand(topic, dataObj.toString(), seq, new CommandCallback() {
         public void onSuccess(Object o, boolean isMQTT) {
            Log.e("LDSOpenSDK", "devUnbindReq onSuccess: " + o.toString());
            if (listener != null) {
               listener.onSuccess();
            }

         }

         public void onFailure(int code, String errorStr) {
            Log.e("LDSOpenSDK", "onFailure: " + code);
            if (listener != null) {
               listener.onError(code, errorStr);
            }

         }

         public void onException(Throwable throwable) {
            if (listener != null) {
               listener.onError(-1, throwable.getMessage());
            }

         }
      });
   }

   public void checkUpdate(String devId, String productId, final CheckUpdateListListener listener) {
      String seq = (new Random()).nextInt() + "";
      String topic = String.format("iot/v1/s/%s/ota/getVerListReq", this.authInfo != null ? this.authInfo.getAssociatedAccount() : "");
      String userid = this.authInfo != null ? this.authInfo.getAssociatedAccount() : "";
      JSONObject dataObj = new JSONObject();
      JSONObject pLoad = new JSONObject();

      try {
         dataObj.put("service", "ota");
         dataObj.put("method", "getVerListReq");
         dataObj.put("seq", seq);
         dataObj.put("srcAddr", String.format("0.%s", userid));
         pLoad.put("devType", "IPC");
         pLoad.put("devId", devId);
         pLoad.put("homeId", this.homeId);
         pLoad.put("productId", productId);
         dataObj.put("payload", pLoad);
      } catch (Exception var10) {
         var10.printStackTrace();
      }

      MqttManage.getInstance().sendMQTTCommand(topic, dataObj.toString(), seq, new CommandCallback() {
         public void onSuccess(Object o, boolean isMQTT) {
            Log.e("LDSOpenSDK", "getVerListReq onSuccess: " + o.toString());
            Gson gson = new Gson();
            getOtaVersionResp resp = (getOtaVersionResp)gson.fromJson(o.toString(), getOtaVersionResp.class);
            if (resp != null && resp.getAck().getCode() == 200) {
               getOtaVersionResp.PayloadBean.VerListBean bean = resp.getPayload().getVerList().size() > 0 ? (getOtaVersionResp.PayloadBean.VerListBean)resp.getPayload().getVerList().get(0) : null;
               if (bean != null && listener != null) {
                  int compare = Utils.compareVersion(bean.getNewVersion(), bean.getOldVersion());
                  Log.e("LDSOpenSDK", "compareVersion: " + compare);
                  if (compare > 0) {
                     listener.onSuccess(true);
                  } else {
                     listener.onSuccess(false);
                  }
               }
            }

         }

         public void onFailure(int code, String errorStr) {
            Log.e("LDSOpenSDK", "onFailure: " + code);
            if (listener != null) {
               listener.onError(code, "");
            }

         }

         public void onException(Throwable throwable) {
            if (listener != null) {
               listener.onError(-1, "");
            }

         }
      });
   }

   public void otaStart() {
      String seq = (new Random()).nextInt() + "";
      String topic = String.format("iot/v1/s/%s/ota/excOtaReq", this.authInfo != null ? this.authInfo.getAssociatedAccount() : "");
      String userid = this.authInfo != null ? this.authInfo.getAssociatedAccount() : "";
      JSONObject dataObj = new JSONObject();
      JSONObject pLoad = new JSONObject();

      try {
         dataObj.put("service", "ota");
         dataObj.put("method", "excOtaReq");
         dataObj.put("seq", seq);
         dataObj.put("srcAddr", String.format("0.%s", userid));
         long time = System.currentTimeMillis();
         SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
         Date d1 = new Date(time);
         String t1 = format.format(d1);
         pLoad.put("timestamp", t1);
         pLoad.put("devId", this.unbindDevid);
         dataObj.put("payload", pLoad);
      } catch (Exception var11) {
         var11.printStackTrace();
      }

      MqttManage.getInstance().sendMQTTCommand(topic, dataObj.toString(), seq, new CommandCallback() {
         public void onSuccess(Object o, boolean isMQTT) {
            Log.e("LDSOpenSDK", "excOtaReq onSuccess: " + o.toString());
         }

         public void onFailure(int code, String errorStr) {
            Log.e("LDSOpenSDK", "excOtaReq onFailure: " + code);
         }

         public void onException(Throwable throwable) {
         }
      });
   }

   public void getRecord(String devid, long recordStaTime, long recordEndTime, final GetRecordListListener listener) {
      JSONObject headerJ = null;

      try {
         headerJ = new JSONObject("{\"terminal\":\"thirdPlatFormUser\",\"active-language\":\"zh_CN\"}");
         headerJ.put("access-token", this.authInfo.getAccessToken());
         headerJ.put("token", this.authInfo.getAccessToken());
         headerJ.put("appKey", this.appKey);
      } catch (JSONException var11) {
         var11.printStackTrace();
      }

      JSONObject dataj = new JSONObject();

      try {
         dataj.put("deviceId", devid);
         dataj.put("recordStaTime", recordStaTime);
         dataj.put("recordEndTime", recordEndTime);
         dataj.put("pageNum", 1);
         dataj.put("pageSize", 100);
         dataj.put("timeout", 20000);
      } catch (JSONException var10) {
         var10.printStackTrace();
      }

      HttpManager.getInstance().requestHttpPost("https://test-smarthome.arnoo.com:443/api/ipc/playbackController/getRecordTimeSlot", headerJ.toString(), dataj.toString(), new HttpRxObserver<String>() {
         protected void onStart(Disposable d) {
         }

         protected void onError(ApiException e) {
            Log.e("LDSOpenSDK", "getRecordTimeSlot onError: " + e.getCode() + " " + e.getMsg());
            if (listener != null) {
               listener.onError(e.getCode(), "");
            }

         }

         protected void onSuccess(String response) {
            Log.e("LDSOpenSDK", "getRecordTimeSlot onSuccess: " + response);
            Gson gson = new Gson();
            GetRecordResp recordResp = (GetRecordResp)gson.fromJson(response, GetRecordResp.class);
            if (recordResp != null && recordResp.getCode() == 200) {
               List<CloudRecord> records = new ArrayList();
               List<GetRecordResp.DataBean.ListBean> datas = recordResp.getData().getList();
               if (datas != null) {
                  Log.e("LDSOpenSDK", "record size: " + datas.size());
                  Iterator var6 = datas.iterator();

                  while(var6.hasNext()) {
                     GetRecordResp.DataBean.ListBean bean = (GetRecordResp.DataBean.ListBean)var6.next();
                     CloudRecord record = new CloudRecord();
                     record.setSta(bean.getSta());
                     record.setEnd(bean.getEnd());
                     records.add(record);
                  }
               }

               if (listener != null) {
                  listener.onSuccess(records);
               }
            } else if (listener != null) {
               listener.onError(recordResp != null ? recordResp.getCode() : -1, "");
            }

         }
      });
   }

   public void playCloudRecord(final String devId, long startTime, final long endTime, LDSPlayer player) {
      this.player = player;
      this.staTime = startTime;
      String seq = (new Random()).nextInt() + "";
      String topic = String.format("iot/v1/s/%s/IPCAM/getPlaybackServerInfoReq", this.authInfo != null ? this.authInfo.getAssociatedAccount() : "");
      String userid = this.authInfo != null ? this.authInfo.getAssociatedAccount() : "";
      JSONObject dataObj = new JSONObject();
      JSONObject pLoad = new JSONObject();

      try {
         dataObj.put("service", "IPCAM");
         dataObj.put("method", "getPlaybackServerInfoReq");
         dataObj.put("seq", seq);
         dataObj.put("srcAddr", String.format("0.%s", userid));
         long time = System.currentTimeMillis();
         SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
         Date d1 = new Date(time);
         String t1 = format.format(d1);
         pLoad.put("timestamp", t1);
         pLoad.put("deviceId", devId);
         pLoad.put("clientId", "app-" + userid);
         dataObj.put("payload", pLoad);
      } catch (Exception var17) {
         var17.printStackTrace();
      }

      MqttManage.getInstance().sendMQTTCommand(topic, dataObj.toString(), seq, new CommandCallback() {
         public void onSuccess(Object o, boolean isMQTT) {
            Log.e("LDSOpenSDK", "getPlaybackServerInfoReq onSuccess: " + o.toString());
            final Gson gson = new Gson();
            GetPlaybackServerInfoResp infoResp = (GetPlaybackServerInfoResp)gson.fromJson(o.toString(), GetPlaybackServerInfoResp.class);
            LDSOpenSDK.this.serverIp = infoResp.getPayload().getServerIP();
            LDSOpenSDK.this.serverPort = infoResp.getPayload().getServerPort();
            LDSOpenSDK.this.heartbeat = infoResp.getPayload().getHeartbeat();
            if (infoResp != null && infoResp.getAck().getCode() == 200) {
               LDSOpenSDK.this.getTaskId(devId, LDSOpenSDK.this.staTime, endTime, new HttpRxObserver<String>() {
                  protected void onStart(Disposable d) {
                  }

                  protected void onError(ApiException e) {
                     Log.e("LDSOpenSDK", "getTaskId onError: " + e.getCode() + "=" + e.getMsg());
                  }

                  protected void onSuccess(String response) {
                     Log.e("LDSOpenSDK", "getTaskId onSuccess: " + response);
                     GetTaskIdResp resp = (GetTaskIdResp)gson.fromJson(response, GetTaskIdResp.class);
                     if (resp != null && resp.getCode() == 200) {
                        LDSOpenSDK.this.taskId = resp.getData().getTaskId();
                        LDSOpenSDK.this.staTime = LDSOpenSDK.this.staTime / 1000L;
                        short cmd = Utils.byteToShortBig(Utils.hexToBytes("0105"));
                        short subCmd = Utils.byteToShortBig(Utils.hexToBytes("0001"));
                        int cmdParam = Utils.byte2intBig(Utils.hexToBytes("00000002"));
                        INettyManager.getInstance().disconnect();
                        INettyManager.getInstance().connect(LDSOpenSDK.this.serverIp, LDSOpenSDK.this.serverPort, LDSOpenSDK.this.heartbeat, cmd, subCmd, cmdParam, LDSOpenSDK.this.tcpListener);
                     }

                  }
               });
            }

         }

         public void onFailure(int code, String errorStr) {
            Log.e("LDSOpenSDK", "getPlaybackServerInfoReq onFailure: " + code);
         }

         public void onException(Throwable throwable) {
         }
      });
   }

   private void openTaskChannel() {
      JSONObject msgObj = new JSONObject();

      try {
         msgObj.put("clientId", this.authInfo.getAssociatedAccount());
         msgObj.put("heartbeat", this.heartbeat);
         msgObj.put("taskId", this.taskId);
      } catch (JSONException var8) {
         var8.printStackTrace();
      }

      short cmd = Utils.byteToShortBig(Utils.hexToBytes("0101"));
      short subCmd = Utils.byteToShortBig(Utils.hexToBytes("0001"));
      int cmdParam = Utils.byte2intBig(Utils.hexToBytes("00000002"));
      RecordVideoHeader head = new RecordVideoHeader();
      head.setVersion(256);
      head.setSequence((new Random()).nextInt());
      head.setCmd(cmd);
      head.setSubCmd(subCmd);
      head.setCmdParam(cmdParam);
      head.setTimeStamp(System.currentTimeMillis());
      head.setContext(1005);
      head.setEncodeType(1);
      head.setResult(4);
      head.setReserve(2);

      try {
         RecordVideoMessage message = new RecordVideoMessage(head, msgObj.toString().getBytes("UTF-8"));
         INettyManager.getInstance().sendTCPCommand(message, new com.leedarson.core.tcp.callback.CommandCallback() {
            public void onSuccess(Object o, boolean isMQTT) {
               Log.e("LDSOpenSDK", "login onSuccess: ");
               RecordVideoMessage resq = (RecordVideoMessage)o;

               try {
                  String body = new String(resq.getPayload(), "UTF-8");
                  Log.e("LDSOpenSDK", "body: " + body);
                  JSONObject bodyObj = new JSONObject(body);
                  if (bodyObj.has("code") && bodyObj.getInt("code") == 200) {
                     LDSOpenSDK.this.isStopRecord = false;
                     LDSOpenSDK.this.getRecordStream(LDSOpenSDK.this.staTime, 1, 10, 1);
                  }
               } catch (Exception var6) {
                  var6.printStackTrace();
               }

            }

            public void onFailure(int code, String errorStr) {
            }

            public void onException(Throwable throwable) {
            }
         });
      } catch (UnsupportedEncodingException var7) {
         var7.printStackTrace();
      }

   }

   private void getRecordStream(long startTime, int type, int framenums, int speed) {
      short cmd = Utils.byteToShortBig(Utils.hexToBytes("0107"));
      short subCmd = Utils.byteToShortBig(Utils.hexToBytes("0001"));
      int cmdParam = Utils.byte2intBig(Utils.hexToBytes("00000002"));
      RecordVideoHeader head = new RecordVideoHeader();
      head.setVersion(256);
      head.setSequence((new Random()).nextInt());
      head.setCmd(cmd);
      head.setSubCmd(subCmd);
      head.setCmdParam(cmdParam);
      head.setTimeStamp(System.currentTimeMillis());
      head.setContext(1005);
      head.setEncodeType(1);
      head.setResult(4);
      head.setReserve(2);

      try {
         JSONObject jsonObject = new JSONObject();
         jsonObject.put("begin", startTime);
         jsonObject.put("type", type);
         jsonObject.put("framenums", framenums);
         jsonObject.put("speed", speed);
         RecordVideoMessage message = new RecordVideoMessage(head, jsonObject.toString().getBytes("UTF-8"));
         INettyManager.getInstance().sendTCPCommand(message, new com.leedarson.core.tcp.callback.CommandCallback() {
            public void onSuccess(Object o, boolean isMQTT) {
               Log.e("LDSOpenSDK", "getRecordStream onSuccess: " + o.toString());
               RecordVideoMessage resq = (RecordVideoMessage)o;
               (LDSOpenSDK.this.new receiveDataTask()).executeOnExecutor(LDSOpenSDK.this.newCachedThreadPool, new RecordVideoMessage[]{resq});
            }

            public void onFailure(int code, String errorStr) {
            }

            public void onException(Throwable throwable) {
            }
         });
      } catch (Exception var12) {
         var12.printStackTrace();
      }

   }

   private void getTaskId(String devId, long staTime, long endTime, HttpRxObserver observer) {
      JSONObject headerJ = null;

      try {
         headerJ = new JSONObject("{\"terminal\":\"thirdPlatFormUser\",\"active-language\":\"zh_CN\"}");
         headerJ.put("access-token", this.authInfo.getAccessToken());
         headerJ.put("token", this.authInfo.getAccessToken());
         headerJ.put("appKey", this.appKey);
      } catch (JSONException var11) {
         var11.printStackTrace();
      }

      JSONObject dataj = new JSONObject();

      try {
         dataj.put("deviceId", devId);
         dataj.put("recordStaTime", staTime);
         dataj.put("recordEndTime", endTime);
      } catch (JSONException var10) {
         var10.printStackTrace();
      }

      HttpManager.getInstance().requestHttpPost("https://test-smarthome.arnoo.com:443/api/ipc/playbackController/playRecord", headerJ.toString(), dataj.toString(), observer);
   }

   class receiveDataTask extends AsyncTask<RecordVideoMessage, Void, Void> {
      protected Void doInBackground(RecordVideoMessage... recordVideoMessages) {
         if (!LDSOpenSDK.this.isStopRecord) {
            while(true) {
               if (!LDSOpenSDK.this.isPauseRecord) {
                  Log.e("LDSOpenSDK", "receiveDataTask: " + recordVideoMessages[0].getHeader().getResult());
                  if (recordVideoMessages[0].getHeader().getResult() == 200) {
                     LDSOpenSDK.this.player.decodeStream(recordVideoMessages[0].getPayload());
                     LDSOpenSDK.this.getRecordStream(LDSOpenSDK.this.staTime, 1, 10, 1);
                  } else if (recordVideoMessages[0].getHeader().getResult() == -15528) {
                  }
                  break;
               }

               try {
                  Thread.sleep(200L);
               } catch (InterruptedException var3) {
                  var3.printStackTrace();
               }
            }
         }

         return null;
      }
   }

   class getBindTask extends AsyncTask<String, Void, Void> {
      protected Void doInBackground(String... strings) {
         int times = 0;

         while(times <= 6 && !LDSOpenSDK.this.bindEnd) {
            try {
               Thread.sleep(15000L);
            } catch (InterruptedException var4) {
               var4.printStackTrace();
            }

            ++times;
            LDSOpenSDK.this.getBindResult(strings[0]);
         }

         return null;
      }
   }

   private static class SingletonHolder {
      private static final LDSOpenSDK INSTANCE = new LDSOpenSDK();
   }
}
