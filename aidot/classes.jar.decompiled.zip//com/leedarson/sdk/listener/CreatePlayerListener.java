package com.leedarson.sdk.listener;

import com.leedarson.sdk.player.LDSPlayer;

public interface CreatePlayerListener {
   void onError(int var1, String var2);

   void onSuccess(LDSPlayer var1);
}
