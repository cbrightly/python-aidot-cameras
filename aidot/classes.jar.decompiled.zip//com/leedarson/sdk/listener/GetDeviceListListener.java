package com.leedarson.sdk.listener;

import com.leedarson.sdk.bean.LDSDeviceInfo;
import java.util.List;

public interface GetDeviceListListener {
   void onError(int var1, String var2);

   void onSuccess(List<LDSDeviceInfo> var1);
}
