package com.leedarson.sdk.listener;

public interface CheckUpdateListListener {
   void onError(int var1, String var2);

   void onSuccess(boolean var1);
}
