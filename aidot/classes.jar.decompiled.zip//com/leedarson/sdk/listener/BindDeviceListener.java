package com.leedarson.sdk.listener;

public interface BindDeviceListener {
   void onError(int var1, String var2);

   void onSuccess();
}
