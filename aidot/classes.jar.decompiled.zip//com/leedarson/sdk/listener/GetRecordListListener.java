package com.leedarson.sdk.listener;

import com.leedarson.sdk.bean.CloudRecord;
import java.util.List;

public interface GetRecordListListener {
   void onError(int var1, String var2);

   void onSuccess(List<CloudRecord> var1);
}
