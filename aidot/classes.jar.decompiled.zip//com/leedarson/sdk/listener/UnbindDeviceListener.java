package com.leedarson.sdk.listener;

public interface UnbindDeviceListener {
   void onError(int var1, String var2);

   void onSuccess();
}
