package com.leedarson.sdk.player;

import android.media.AudioRecord;
import android.os.AsyncTask;
import android.util.Log;
import android.view.Surface;
import com.leedarson.core.Utils.Utils;
import com.leedarson.core.tcp.INettyManager;
import com.tutk.IOTC.TutkListener;
import com.tutk.IOTC.TutkManager;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import leedarson.platform.g711codec.G711Coder;
import leedarson.platform.playersdk.PlayerSDK;

public class LDSPlayer {
   private static final String TAG = "LDSPlayer";
   private PlayerSDK playerSDK;
   ExecutorService newCachedThreadPool = Executors.newCachedThreadPool();
   private String p2pId;
   private String account;
   private String pwd;
   private PlayerSDK.CallBack playerSDKback = new PlayerSDK.CallBack() {
      public int playerCallBack(int type, byte[] data, int dateLen) {
         Log.e("LDSPlayer", "playerCallBack type:" + type + " len:" + dateLen);
         return 0;
      }
   };
   private TutkListener tutkListener = new TutkListener() {
      public void OnReceiveAudioData(int ret, long timestap, byte[] data) {
         if (ret > 0 && LDSPlayer.this.playerSDK != null) {
            LDSPlayer.this.playerSDK.soundAudio(data, ret, timestap, 2);
         }

      }

      public void OnreceiveVideoData(int ret, long timestap, byte[] data) {
         if (ret > 0 && LDSPlayer.this.playerSDK != null) {
            LDSPlayer.this.playerSDK.drawVideo(data, ret, timestap, 100, 100, 1);
         }

      }
   };
   int frequency = 8000;
   int channel = 16;
   int sampbit = 2;
   int minBufferSize;
   boolean isRecord;
   private G711Coder.CoderResult mEncodeRes;
   private AudioRecord audioRecord;

   public LDSPlayer(String p2pId, String account, String pwd) {
      this.p2pId = p2pId;
      this.account = account;
      this.pwd = pwd;
   }

   public LDSPlayer() {
   }

   public int init() {
      int pret = PlayerSDK.initPlayerSDK(1, "", 0);
      if (pret == 0) {
         int tret = TutkManager.getInstance().init();
         return tret;
      } else {
         return pret;
      }
   }

   public int initPlayer() {
      int pret = PlayerSDK.initPlayerSDK(1, "", 0);
      return pret;
   }

   public void unInit() {
      TutkManager.getInstance().unInit();
   }

   public void setLogLevel(int logLevel) {
      PlayerSDK.setLogLevel(logLevel);
   }

   public void createPlayer() {
      this.playerSDK = new PlayerSDK();
      int ret = this.playerSDK.createPlayerSDK(1, this.playerSDKback);
   }

   public void startPlay(Surface surface) {
      if (this.playerSDK != null) {
         this.playerSDK.setAVSyncMode(1);
         this.playerSDK.setMinBuffTime(5000);
         this.playerSDK.startDecoderPlay(surface, 1, 2);
      }

      TutkManager.getInstance().setListener(this.tutkListener);
      TutkManager.getInstance().startGetStream(this.p2pId, this.account, this.pwd);
   }

   public void stopPlay() {
      if (this.playerSDK != null) {
         this.playerSDK.stopDecoderPlay();
      }

   }

   public void release() {
      if (this.playerSDK != null) {
         this.playerSDK.stopDecoderPlay();
      }

      PlayerSDK.unInitPlayerSDK();
      TutkManager.getInstance().stopStream();
      INettyManager.getInstance().disconnect();
   }

   public void pausePlay() {
      if (this.playerSDK != null) {
         this.playerSDK.pause();
      }

   }

   public void resumePlay() {
      if (this.playerSDK != null) {
         this.playerSDK.resume();
      }

   }

   public void snapshot(String path) {
      if (this.playerSDK != null) {
         this.playerSDK.snapshot(path, 0);
      }

   }

   public void startRecode(String path, long maxTime) {
      if (this.playerSDK != null) {
         this.playerSDK.startRecoder(path, 0, maxTime);
      }

   }

   public void stopRecode() {
      if (this.playerSDK != null) {
         this.playerSDK.stopRecoder("");
      }

   }

   public void changeMuteState(boolean mute) {
      if (this.playerSDK != null) {
         this.playerSDK.changeMuteState(mute);
      }

   }

   public void startTalk() {
      this.isRecord = true;
      (new LDSPlayer.StartTalkTask()).executeOnExecutor(this.newCachedThreadPool, new Integer[0]);
   }

   public void stopTalk() {
      this.isRecord = false;
      (new LDSPlayer.StopTalkTask()).executeOnExecutor(this.newCachedThreadPool, new Integer[0]);
   }

   private AudioRecord initAudioRecord(int frequency, int channel, int sampbit) {
      this.minBufferSize = AudioRecord.getMinBufferSize(frequency, channel, sampbit);
      AudioRecord audioRecord = null;
      audioRecord = new AudioRecord(1, frequency, channel, sampbit, this.minBufferSize);
      G711Coder.init();
      this.mEncodeRes = new G711Coder.CoderResult();
      return audioRecord;
   }

   public void decodeStream(byte[] data) {
      Log.e("LDSPlayer", "decodeStream: " + data.length);

      int payloadLen;
      for(int hasDecode = 0; data.length - hasDecode >= 17; hasDecode += payloadLen + 17) {
         byte[] vbs = new byte[2];
         System.arraycopy(data, 0, vbs, 0, 2);
         int frameType = data[hasDecode + 2];
         int audioCodec = data[hasDecode + 3];
         byte[] tbs = new byte[8];
         System.arraycopy(data, hasDecode + 4, tbs, 0, 8);
         long timeStamp1 = Utils.byte2longBig(tbs);
         int encryptionType = data[hasDecode + 12];
         byte[] pbs = new byte[4];
         System.arraycopy(data, hasDecode + 13, pbs, 0, 4);
         payloadLen = Utils.byte2intBig(pbs);
         if (encryptionType == 0) {
            byte[] abs;
            if (frameType == 5) {
               if (audioCodec != 0 && audioCodec == 1) {
                  abs = new byte[payloadLen];
                  System.arraycopy(data, hasDecode + 17, abs, 0, payloadLen);
                  if (this.playerSDK != null) {
                     this.playerSDK.soundAudio(abs, payloadLen, timeStamp1, 2);
                  }
               }
            } else if ((frameType == 2 || frameType == 3 || frameType == 4) && data.length - hasDecode >= payloadLen + 17) {
               if (frameType == 2) {
               }

               abs = new byte[payloadLen];
               System.arraycopy(data, hasDecode + 17, abs, 0, payloadLen);
               int bak = true;
               if (this.playerSDK != null) {
                  int bak = this.playerSDK.drawVideo(abs, payloadLen, timeStamp1, 100, 100, 1);
                  if (bak == -1105) {
                     try {
                        Thread.sleep(7000L);
                        this.playerSDK.drawVideo(abs, payloadLen, timeStamp1, 100, 100, 1);
                     } catch (InterruptedException var15) {
                        var15.printStackTrace();
                     }
                  }
               }
            }
         } else if (encryptionType == 1) {
         }
      }

   }

   class StopTalkTask extends AsyncTask<Integer, Void, Void> {
      protected Void doInBackground(Integer... avIndex) {
         if (LDSPlayer.this.audioRecord != null) {
            LDSPlayer.this.audioRecord.stop();
         }

         if (LDSPlayer.this.playerSDK != null) {
            LDSPlayer.this.playerSDK.changeMuteState(true);
         }

         TutkManager.getInstance().closeTalk();
         return null;
      }
   }

   class StartTalkTask extends AsyncTask<Integer, Void, Void> {
      protected Void doInBackground(Integer... avIndex) {
         Log.e("LDSPlayer", "StartTalkTask doInBackground: ");
         if (LDSPlayer.this.playerSDK != null) {
            LDSPlayer.this.playerSDK.changeMuteState(true);
         }

         int ret = TutkManager.getInstance().openTalkChannel();
         Log.e("LDSPlayer", "openTalkChannel: " + ret);
         if (ret > 0) {
            if (LDSPlayer.this.audioRecord == null) {
               LDSPlayer.this.audioRecord = LDSPlayer.this.initAudioRecord(LDSPlayer.this.frequency, LDSPlayer.this.channel, LDSPlayer.this.sampbit);
            }

            if (LDSPlayer.this.audioRecord != null) {
               boolean hasInit = false;

               while(!hasInit && LDSPlayer.this.isRecord) {
                  try {
                     Thread.sleep(10L);
                  } catch (InterruptedException var7) {
                     var7.printStackTrace();
                  }

                  int state = LDSPlayer.this.audioRecord.getState();
                  if (state == 1) {
                     hasInit = true;
                     LDSPlayer.this.audioRecord.startRecording();
                  }
               }

               byte[] audioData = new byte[LDSPlayer.this.minBufferSize];

               while(LDSPlayer.this.isRecord) {
                  int size = LDSPlayer.this.audioRecord.read(audioData, 0, audioData.length);
                  if (size == audioData.length) {
                     G711Coder.g711aEncode(audioData, audioData.length, LDSPlayer.this.mEncodeRes);
                     int sendResult = TutkManager.getInstance().sendTalkData(LDSPlayer.this.mEncodeRes.dataLen, LDSPlayer.this.mEncodeRes.dataArr);
                     Log.e("LDSPlayer", "sendTalkData: " + sendResult);
                  }
               }
            }
         }

         return null;
      }

      protected void onPostExecute(Void result) {
      }
   }
}
