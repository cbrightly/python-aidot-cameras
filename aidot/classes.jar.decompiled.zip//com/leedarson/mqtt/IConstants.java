package com.leedarson.mqtt;

public class IConstants {
   public static final int MQTT_CONNECTING = 0;
   public static final int MQTT_CONNECTED = 1;
   public static final int MQTT_RECONNECTINT = 2;
   public static final int MQTT_DISCONNECTED = 3;
   public static final int MQTT_CONNECT_FAIL = 4;
   public static final int MQTT_CONNECT_LOST = 5;
   public static final int MQTT_CONNECT_END = 6;
}
