package com.leedarson.mqtt.pahomqtt;

enum Status {
   OK,
   ERROR,
   NO_RESULT;
}
