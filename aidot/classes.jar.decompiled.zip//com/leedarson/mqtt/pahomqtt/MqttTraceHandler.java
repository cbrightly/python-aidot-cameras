package com.leedarson.mqtt.pahomqtt;

public interface MqttTraceHandler {
   void traceDebug(String var1, String var2);

   void traceError(String var1, String var2);

   void traceException(String var1, String var2, Exception var3);
}
