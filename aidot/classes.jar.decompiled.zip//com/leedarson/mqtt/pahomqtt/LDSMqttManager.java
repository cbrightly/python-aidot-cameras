package com.leedarson.mqtt.pahomqtt;

import android.content.Context;
import android.util.Log;
import com.leedarson.mqtt.listener.IMqttListener;
import com.leedarson.mqtt.listener.LDSMqttListener;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class LDSMqttManager {
   private Context context;
   private boolean isInit;
   private MqttAndroidClient mqttAndroidClient;
   private MqttCallbackExtended mqttCallbackExtended;
   private IMqttActionListener iMqttActionListener;
   private String clientId;
   private LDSMqttListener listener;
   private MqttConnectOptions mqttConnectOptions;
   private DisconnectedBufferOptions disconnectedBufferOptions;
   private boolean isConnect;
   private boolean isConnectEnd;
   private boolean isDisconnect;
   private String userName;

   public boolean isConnect() {
      try {
         return this.mqttAndroidClient != null ? this.mqttAndroidClient.isConnected() : false;
      } catch (Exception var2) {
         return false;
      }
   }

   private LDSMqttManager() {
      this.isInit = false;
      this.isConnect = false;
      this.isConnectEnd = false;
      this.isDisconnect = false;
   }

   public static LDSMqttManager getInstance() {
      return LDSMqttManager.SingletonHolder.INSTANCE;
   }

   public void setListener(LDSMqttListener listener) {
      this.listener = listener;
   }

   public void initCredentials(Context context, String username, String password, String clientId, boolean isReConnect, String willTopic, String willMsg) {
      this.userName = username;
      if (this.isConnect()) {
         this.disconnect();
      }

      this.clear();
      this.context = context;
      this.isInit = true;
      this.isDisconnect = false;
      this.clientId = clientId;

      try {
         this.mqttConnectOptions = new MqttConnectOptions();
         if (username != null && password != null) {
            this.mqttConnectOptions.setUserName(username);
            this.mqttConnectOptions.setPassword(password.toCharArray());
         }

         this.mqttConnectOptions.setAutomaticReconnect(isReConnect);
         this.mqttConnectOptions.setCleanSession(true);
         this.mqttConnectOptions.setMaxInflight(1000);
         this.mqttConnectOptions.setKeepAliveInterval(50);
         this.mqttConnectOptions.setConnectionTimeout(10);
         this.mqttConnectOptions.setMqttVersion(4);
         if (willTopic != null && willMsg != null) {
            this.mqttConnectOptions.setWill(willTopic, willMsg.getBytes(), 1, false);
         }

         this.disconnectedBufferOptions = new DisconnectedBufferOptions();
         this.disconnectedBufferOptions.setBufferEnabled(true);
         this.disconnectedBufferOptions.setBufferSize(100);
         this.disconnectedBufferOptions.setPersistBuffer(false);
         this.disconnectedBufferOptions.setDeleteOldestMessages(false);
         if (this.listener != null) {
            this.listener.initLocalSuccess();
         }
      } catch (Exception var9) {
         if (this.listener != null) {
            this.listener.initLocalFail();
         }
      }

   }

   public void connect(String serverUri) {
      this.isConnectEnd = false;

      try {
         this.listener.onLocalMqttStateChanged(0, (String)null);
         if (this.mqttCallbackExtended == null) {
            this.mqttCallbackExtended = new MqttCallbackExtended() {
               public void connectComplete(boolean reconnect, String serverURI) {
                  LDSMqttManager.this.isConnect = true;
                  if (reconnect) {
                     LDSMqttManager.this.listener.onLocalMqttStateChanged(1, (String)null);
                  } else {
                     LDSMqttManager.this.listener.onLocalMqttStateChanged(1, (String)null);
                  }

               }

               public void connectionLost(Throwable cause) {
                  if (cause != null) {
                     cause.printStackTrace();
                  }

                  LDSMqttManager.this.isConnect = false;
                  LDSMqttManager.this.listener.onLocalMqttStateChanged(3, (String)null);
                  if (!LDSMqttManager.this.isDisconnect) {
                     LDSMqttManager.this.listener.onLocalMqttStateChanged(5, (String)null);
                  }

               }

               public void messageArrived(String topic, MqttMessage message) throws Exception {
                  if (LDSMqttManager.this.listener != null) {
                     LDSMqttManager.this.listener.onLocalMessageArrived(topic, new String(message.getPayload()));
                  }

               }

               public void deliveryComplete(IMqttDeliveryToken token) {
               }
            };
         }

         if (this.iMqttActionListener == null) {
            this.iMqttActionListener = new IMqttActionListener() {
               public void onSuccess(IMqttToken asyncActionToken) {
                  LDSMqttManager.this.isConnectEnd = true;

                  try {
                     LDSMqttManager.this.isConnect = true;
                     LDSMqttManager.this.listener.onLocalMqttStateChanged(1, (String)null);
                     DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
                     disconnectedBufferOptions.setBufferEnabled(true);
                     disconnectedBufferOptions.setBufferSize(100);
                     disconnectedBufferOptions.setPersistBuffer(false);
                     disconnectedBufferOptions.setDeleteOldestMessages(false);
                     if (LDSMqttManager.this.mqttAndroidClient != null) {
                        LDSMqttManager.this.mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);
                     }
                  } catch (Exception var3) {
                  }

               }

               public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                  LDSMqttManager.this.listener.onLocalMqttStateChanged(4, (String)null);
                  LDSMqttManager.this.isConnect = false;
                  LDSMqttManager.this.isConnectEnd = true;
                  if (exception != null) {
                     exception.printStackTrace();
                     MqttException e = (MqttException)exception;
                     if (e.getReasonCode() == 4) {
                        LDSMqttManager.this.listener.onLocalMqttStateChanged(6, (String)null);
                     }
                  }

               }
            };
         }

         if (this.mqttAndroidClient == null) {
            this.mqttAndroidClient = new MqttAndroidClient(this.context, serverUri, this.clientId);
         }

         this.mqttAndroidClient.setCallback(this.mqttCallbackExtended);
         this.mqttAndroidClient.connect(this.mqttConnectOptions, (Object)null, this.iMqttActionListener);
      } catch (Exception var3) {
         var3.printStackTrace();
         this.listener.onLocalMqttStateChanged(4, var3.getMessage());
         this.isConnect = false;
         this.isConnectEnd = true;
      }

   }

   public void disconnect() {
      try {
         this.isDisconnect = true;
         this.mqttAndroidClient.disconnect();
         this.listener.onLocalMqttStateChanged(3, (String)null);
         this.isConnect = false;
      } catch (Exception var2) {
      }

   }

   public void close() {
      try {
         this.mqttAndroidClient.close();
      } catch (Exception var2) {
      }

   }

   public void subscribe(String topic, final IMqttListener listener) {
      Log.e("==", "subscribe: " + topic);
      this.mqttAndroidClient.subscribe(topic, 1, (Object)null, new IMqttActionListener() {
         public void onSuccess(IMqttToken asyncActionToken) {
            listener.onSuccess();
         }

         public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
            listener.onFailure(exception);
         }
      });
   }

   public void unsubscribe(String topic, final IMqttListener listener) {
      this.mqttAndroidClient.unsubscribe((String)topic, (Object)null, new IMqttActionListener() {
         public void onSuccess(IMqttToken asyncActionToken) {
            listener.onSuccess();
         }

         public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
            listener.onFailure(exception);
         }
      });
   }

   public void publish(final String topic, String msg, final IMqttListener listener) {
      final MqttMessage message = new MqttMessage();
      message.setQos(1);
      message.setPayload(msg.getBytes());
      this.mqttAndroidClient.publish(topic, message, (Object)null, new IMqttActionListener() {
         public void onSuccess(IMqttToken asyncActionToken) {
            Log.e("===", "publish onSuccess: " + topic + " msg:" + message);
            if (listener != null) {
               listener.onSuccess();
            }

         }

         public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
            if (listener != null) {
               listener.onFailure(exception);
            }

         }
      });
   }

   public void clear() {
      this.mqttAndroidClient = null;
      this.mqttCallbackExtended = null;
      this.iMqttActionListener = null;
   }

   // $FF: synthetic method
   LDSMqttManager(Object x0) {
      this();
   }

   private static class SingletonHolder {
      private static final LDSMqttManager INSTANCE = new LDSMqttManager();
   }
}
