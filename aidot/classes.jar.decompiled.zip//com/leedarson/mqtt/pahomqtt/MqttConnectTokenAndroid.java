package com.leedarson.mqtt.pahomqtt;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttAsyncClient;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.internal.wire.MqttWireMessage;

class MqttConnectTokenAndroid implements IMqttToken {
   private boolean sessionPresent;

   MqttConnectTokenAndroid(boolean sessionPresent) {
      this.sessionPresent = sessionPresent;
   }

   void setMessage(MqttMessage message) {
   }

   void notifyDelivery(MqttMessage delivered) {
   }

   public void waitForCompletion() throws MqttException {
   }

   public void waitForCompletion(long timeout) throws MqttException {
   }

   public boolean isComplete() {
      return false;
   }

   public MqttException getException() {
      return null;
   }

   public IMqttActionListener getActionCallback() {
      return null;
   }

   public void setActionCallback(IMqttActionListener listener) {
   }

   public IMqttAsyncClient getClient() {
      return null;
   }

   public String[] getTopics() {
      return new String[0];
   }

   public Object getUserContext() {
      return null;
   }

   public void setUserContext(Object userContext) {
   }

   public int getMessageId() {
      return 0;
   }

   public int[] getGrantedQos() {
      return new int[0];
   }

   public boolean getSessionPresent() {
      return this.sessionPresent;
   }

   public MqttWireMessage getResponse() {
      return null;
   }
}
