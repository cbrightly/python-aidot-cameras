package com.leedarson.mqtt.pahomqtt;

import android.os.Binder;

class MqttServiceBinder extends Binder {
   private MqttService mqttService;
   private String activityToken;

   MqttServiceBinder(MqttService mqttService) {
      this.mqttService = mqttService;
   }

   public MqttService getService() {
      return this.mqttService;
   }

   public String getActivityToken() {
      return this.activityToken;
   }

   void setActivityToken(String activityToken) {
      this.activityToken = activityToken;
   }
}
