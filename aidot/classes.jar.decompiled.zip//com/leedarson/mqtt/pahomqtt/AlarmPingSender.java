package com.leedarson.mqtt.pahomqtt;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.PowerManager;
import android.os.Build.VERSION;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttPingSender;
import org.eclipse.paho.client.mqttv3.MqttToken;
import org.eclipse.paho.client.mqttv3.internal.ClientComms;

class AlarmPingSender implements MqttPingSender {
   private static final String TAG = "AlarmPingSender";
   private ClientComms comms;
   private MqttService service;
   private BroadcastReceiver alarmReceiver;
   private AlarmPingSender that;
   private PendingIntent pendingIntent;
   private volatile boolean hasStarted = false;

   public AlarmPingSender(MqttService service) {
      if (service == null) {
         throw new IllegalArgumentException("Neither service nor client can be null.");
      } else {
         this.service = service;
         this.that = this;
      }
   }

   public void init(ClientComms comms) {
      this.comms = comms;
      this.alarmReceiver = new AlarmPingSender.AlarmReceiver();
   }

   public void start() {
      String action = "MqttService.pingSender." + this.comms.getClient().getClientId();
      Log.d("AlarmPingSender", "Register alarmreceiver to MqttService" + action);
      this.service.registerReceiver(this.alarmReceiver, new IntentFilter(action));
      this.pendingIntent = PendingIntent.getBroadcast(this.service, 0, new Intent(action), 134217728);
      this.schedule(this.comms.getKeepAlive());
      this.hasStarted = true;
   }

   public void stop() {
      Log.d("AlarmPingSender", "Unregister alarmreceiver to MqttService" + this.comms.getClient().getClientId());
      if (this.hasStarted) {
         if (this.pendingIntent != null) {
            AlarmManager alarmManager = (AlarmManager)this.service.getSystemService("alarm");
            alarmManager.cancel(this.pendingIntent);
         }

         this.hasStarted = false;

         try {
            this.service.unregisterReceiver(this.alarmReceiver);
         } catch (IllegalArgumentException var2) {
         }
      }

   }

   public void schedule(long delayInMilliseconds) {
      long nextAlarmInMilliseconds = System.currentTimeMillis() + delayInMilliseconds;
      Log.d("AlarmPingSender", "Schedule next alarm at " + nextAlarmInMilliseconds);
      AlarmManager alarmManager = (AlarmManager)this.service.getSystemService("alarm");
      if (VERSION.SDK_INT >= 23) {
         Log.d("AlarmPingSender", "Alarm scheule using setExactAndAllowWhileIdle, next: " + delayInMilliseconds);
         alarmManager.setExactAndAllowWhileIdle(0, nextAlarmInMilliseconds, this.pendingIntent);
      } else if (VERSION.SDK_INT >= 19) {
         Log.d("AlarmPingSender", "Alarm scheule using setExact, delay: " + delayInMilliseconds);
         alarmManager.setExact(0, nextAlarmInMilliseconds, this.pendingIntent);
      } else {
         alarmManager.set(0, nextAlarmInMilliseconds, this.pendingIntent);
      }

   }

   class AlarmReceiver extends BroadcastReceiver {
      private final String wakeLockTag;
      private AlarmPingSender.PingAsyncTask pingRunner;
      private WakeLock wakelock;

      AlarmReceiver() {
         this.wakeLockTag = "MqttService.client." + AlarmPingSender.this.that.comms.getClient().getClientId();
         this.pingRunner = null;
      }

      @SuppressLint({"Wakelock"})
      public void onReceive(Context context, Intent intent) {
         PowerManager pm = (PowerManager)AlarmPingSender.this.service.getSystemService("power");
         this.wakelock = pm.newWakeLock(1, this.wakeLockTag);
         this.wakelock.acquire();
         if (this.pingRunner != null && this.pingRunner.cancel(true)) {
            Log.d("AlarmPingSender", "Previous ping async task was cancelled at:" + System.currentTimeMillis());
         }

         this.pingRunner = AlarmPingSender.this.new PingAsyncTask();
         this.pingRunner.execute(new ClientComms[]{AlarmPingSender.this.comms});
         if (this.wakelock.isHeld()) {
            this.wakelock.release();
         }

      }
   }

   private class PingAsyncTask extends AsyncTask<ClientComms, Void, Boolean> {
      boolean success;

      private PingAsyncTask() {
         this.success = false;
      }

      protected Boolean doInBackground(ClientComms... comms) {
         MqttToken token = comms[0].checkForActivity(new IMqttActionListener() {
            public void onSuccess(IMqttToken asyncActionToken) {
               PingAsyncTask.this.success = true;
            }

            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
               Log.d("AlarmPingSender", "Ping async task : Failed.");
               PingAsyncTask.this.success = false;
            }
         });

         try {
            if (token != null) {
               token.waitForCompletion();
            } else {
               Log.d("AlarmPingSender", "Ping async background : Ping command was not sent by the client.");
            }
         } catch (MqttException var4) {
            Log.d("AlarmPingSender", "Ping async background : Ignore MQTT exception : " + var4.getMessage());
         } catch (Exception var5) {
            Log.d("AlarmPingSender", "Ping async background : Ignore unknown exception : " + var5.getMessage());
         }

         if (!this.success) {
            Log.d("AlarmPingSender", "Ping async background task completed at " + System.currentTimeMillis() + " Success is " + this.success);
         }

         return new Boolean(this.success);
      }

      protected void onPostExecute(Boolean success) {
         if (!success) {
            Log.d("AlarmPingSender", "Ping async task onPostExecute() Success is " + this.success);
         }

      }

      protected void onCancelled(Boolean success) {
         Log.d("AlarmPingSender", "Ping async task onCancelled() Success is " + this.success);
      }

      // $FF: synthetic method
      PingAsyncTask(Object x1) {
         this();
      }
   }
}
