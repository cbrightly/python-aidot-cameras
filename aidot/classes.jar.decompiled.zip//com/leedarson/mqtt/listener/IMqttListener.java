package com.leedarson.mqtt.listener;

public interface IMqttListener {
   void onSuccess();

   void onFailure(Throwable var1);
}
