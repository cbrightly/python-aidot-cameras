package com.leedarson.mqtt.listener;

public interface LDSMqttListener {
   void initLocalSuccess();

   void initLocalFail();

   void onLocalMqttStateChanged(int var1, String var2);

   void onLocalMessageArrived(String var1, String var2);
}
