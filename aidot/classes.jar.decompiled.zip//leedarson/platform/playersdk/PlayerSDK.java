package leedarson.platform.playersdk;

import android.view.Surface;

public class PlayerSDK {
   public static final int PURE_PLAYER = 0;
   public static final int DECODER_PLAYER = 1;
   public static final int FULL_PLAYER = 2;
   public static final int FORMAT_PLAYER = 3;
   private int mPlayerHandle = -1;
   private int mPlayerType = -1;
   private PlayerSDK.CallBack mCb = null;

   private static final native int init(int var0, String var1, int var2);

   private static final native void unInit();

   private static final native int getSupportMaxPlayer();

   private static final native int setSDKLogLevel(int var0);

   private final native int createPlayer(int var1);

   private final native int destroyPlayer(int var1);

   private final native int setCallBack(int var1, String var2);

   private final native int initVideoSurface(int var1, Surface var2, int var3, int var4, int var5);

   private final native void unInitVideoSurface(int var1);

   private final native int initAudioSound(int var1, int var2, int var3, int var4);

   private final native void unInitAudioSound(int var1);

   private final native int playVideo(int var1, byte[] var2, int var3, long var4, int var6, int var7, int var8);

   private final native int playAudio(int var1, byte[] var2, int var3, long var4, int var6);

   private final native void clearDisplay(int var1);

   private final native void changeMuteState(int var1, boolean var2);

   private final native int start(int var1, Surface var2, int var3, String var4, int var5);

   private final native int stop(int var1, boolean var2);

   private final native int startPlay(int var1, Surface var2, int var3, int var4);

   private final native void stopPlay(int var1);

   private final native int snapshot(int var1, String var2, int var3);

   private final native int startRecoder(int var1, String var2, int var3, long var4);

   private final native int stopRecoder(int var1, String var2);

   private final native int surfaceViewChanged(int var1, int var2, int var3);

   private final native int setAVSyncMode(int var1, int var2);

   private final native int getAvSyncMode(int var1);

   private final native int swapSurface(int var1, Surface var2);

   private final native void removeSurface(int var1);

   private final native int setSurface(int var1, Surface var2);

   private final native int seek(int var1, long var2);

   private final native int pause(int var1);

   private final native int resume(int var1);

   private final native void clearBuffer(int var1);

   private final native void setMaxBufferTime(int var1, int var2);

   private final native long getDuration(int var1);

   private final native int setDecoderType(int var1, int var2);

   private final native int setMultiThreadDecode(int var1, boolean var2, int var3);

   private final native int setDisplayMode(int var1, int var2);

   private final native int setDisplayRotate(int var1, int var2);

   private final native int sendFormatData(int var1, byte[] var2, int var3);

   private final native int setMinBuffTime(int var1, int var2);

   private final native int setPolicy(int var1, int var2);

   public static int initPlayerSDK(int max, String logPath, int logSize) {
      return init(max, logPath, logSize);
   }

   public static void unInitPlayerSDK() {
      unInit();
   }

   public static int setLogLevel(int level) {
      return setSDKLogLevel(level);
   }

   public int createPlayerSDK(int type, PlayerSDK.CallBack callBack) {
      if (callBack == null) {
         return -1;
      } else {
         this.mPlayerHandle = this.createPlayer(type);
         if (this.mPlayerHandle >= 0) {
            this.mPlayerType = type;
            if (null != callBack) {
               this.mCb = callBack;
               return this.setCallBack(this.mPlayerHandle, "playerNativeCallBack");
            }
         }

         return this.mPlayerHandle;
      }
   }

   public final int playerNativeCallBack(int type, byte[] data, int dataLen) {
      if (null != this.mCb) {
         this.mCb.playerCallBack(type, data, dataLen);
      }

      return 0;
   }

   public int destoryPlayerSDK() {
      int ret = this.destroyPlayer(this.mPlayerHandle);
      this.mPlayerType = -1;
      return ret;
   }

   public int startDecoderPlay(Surface surface, int videoCodec, int audioCodec) {
      return this.mPlayerType == 1 ? this.startPlay(this.mPlayerHandle, surface, videoCodec, audioCodec) : -1;
   }

   public void stopDecoderPlay() {
      this.stopPlay(this.mPlayerHandle);
   }

   public int snapshot(String path, int format) {
      return this.snapshot(this.mPlayerHandle, path, format);
   }

   public int startRecoder(String path, int format, long maxTime) {
      return this.startRecoder(this.mPlayerHandle, path, format, maxTime);
   }

   public int stopRecoder(String newName) {
      return this.stopRecoder(this.mPlayerHandle, newName);
   }

   public int setAVSyncMode(int mode) {
      return this.setAVSyncMode(this.mPlayerHandle, mode);
   }

   public int pause() {
      return this.pause(this.mPlayerHandle);
   }

   public int resume() {
      return this.resume(this.mPlayerHandle);
   }

   public void clearBuffer() {
      this.clearBuffer(this.mPlayerHandle);
   }

   public void setMaxBuffTime(int buffTime) {
      this.setMaxBufferTime(this.mPlayerHandle, buffTime);
   }

   public int setMinBuffTime(int bufTime) {
      return this.setMinBuffTime(this.mPlayerHandle, bufTime);
   }

   public int drawVideo(byte[] data, int len, long timeStamp, int width, int height, int codec) {
      return this.playVideo(this.mPlayerHandle, data, len, timeStamp, width, height, codec);
   }

   public int soundAudio(byte[] data, int len, long timeStamp, int codec) {
      return this.playAudio(this.mPlayerHandle, data, len, timeStamp, codec);
   }

   public void changeMuteState(boolean mute) {
      this.changeMuteState(this.mPlayerHandle, mute);
   }

   static {
      try {
         System.loadLibrary("xplayer");
      } catch (UnsatisfiedLinkError var1) {
         System.out.println("loadLibrary(xplayer)," + var1.getMessage());
      }

   }

   public interface CallBack {
      int playerCallBack(int var1, byte[] var2, int var3);
   }
}
