package leedarson.platform.g711codec;

public class G711Coder {
   public static final native int init();

   public static final native void unInit();

   public static final native int g711aEncode(byte[] var0, int var1, G711Coder.CoderResult var2);

   public static final native int g711uEncode(byte[] var0, int var1, G711Coder.CoderResult var2);

   public static final native int g711aDecode(byte[] var0, int var1, G711Coder.CoderResult var2);

   public static final native int g711uDecode(byte[] var0, int var1, G711Coder.CoderResult var2);

   static {
      System.loadLibrary("G711");
   }

   public static class CoderResult {
      public byte[] dataArr;
      public int dataLen;

      public void setData(byte[] dataArr, int dataLen) {
         this.dataArr = dataArr;
         this.dataLen = dataLen;
      }
   }
}
