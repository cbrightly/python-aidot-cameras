// const i18n = require('i18next');
// const dayjs = require('dayjs');
// const reactI18next = require('react-i18next');

// const { initReactI18next } = reactI18next;

// interface ILOCALES {
//   [propName: string]: string;
// }

// const LANGUAGES = {
//   'it-IT': 'Italiano',
//   'de-DE': 'Deutsch',
//   'en-US': 'English (US)',
//   'es-ES': 'Español',
//   'in-ID': 'Bahasa Indonesia',
//   'fr-FR': 'Français',
//   'en-GB': 'English (UK)',
//   'ja-JP': '日本語(JP)',
//   'th-TH': 'ไทย',
// };

// const defaultNameSpace = 'LDS-Payment';
// const supportedLngs = Object.keys(LANGUAGES);
// let finalLanguage: string | null = window.localStorage.getItem('locale'); // 1. 本地语言

// if (!finalLanguage || !supportedLngs.includes(finalLanguage)) {
//   const navigatorLanguage = window.navigator.language;
//   if (supportedLngs.includes(navigatorLanguage)) {
//     finalLanguage = navigatorLanguage; // 2. 浏览器精确语言
//   } else {
//     const navigatorPrefix = navigatorLanguage.split('-')[0];
//     const similarLanguage = supportedLngs.find(
//       (lang) => lang.split('-')[0] === navigatorPrefix,
//     );
//     if (similarLanguage) {
//       finalLanguage = similarLanguage; // 3. 浏览器相似语言
//     } else {
//       finalLanguage = 'en-US'; // 4. 默认语言
//     }
//   }
//   if (finalLanguage) {
//     window.localStorage.setItem('locale', finalLanguage);
//   }
// }

// const setI18nLanguage = (lang: string) => {
//   if (!i18n.hasResourceBundle(lang, defaultNameSpace)) {
//     // 1. 加载指定语言
//     import(/* webpackChunkName: "i18n.locale." */ `./locales/${lang}`)
//       .then((bundle) => {
//         i18n.addResourceBundle(lang, defaultNameSpace, bundle.default);
//       })
//       .catch(() => {
//         const defaultLanguage = 'en-US';
//         if (!i18n.hasResourceBundle(defaultLanguage, defaultNameSpace)) {
//           // 2. 加载默认语言
//           import(
//             /* webpackChunkName: "i18n.locale." */ `./locales/${defaultLanguage}`
//           ).then((bundle) => {
//             i18n.addResourceBundle(
//               defaultLanguage,
//               defaultNameSpace,
//               bundle.default,
//             );
//           });
//         }
//       });
//   }
// };

// const setDayjsLanguage = (lang: string) => {
//   const LOCALES: ILOCALES = {
//     'cs-CZ': 'cs',
//     'de-DE': 'de',
//     'en-GB': 'en-gb',
//     'en-UK': 'en-gb',
//     'en-US': 'en',
//     'es-ES': 'es',
//     'es-MX': 'es-mx',
//     'fr-FR': 'fr',
//     'fr-CA': 'fr-ca',
//     'it-IT': 'it',
//     'ja-JP': 'ja',
//     ja: 'ja',
//     'pl-PL': 'pl',
//     'nl-NL': 'nl',
//     'zh-CN': 'zh-cn',
//   };
//   const locale = LOCALES[lang] || 'en-US';
//   const currentLocale = dayjs.locale();
//   if (currentLocale !== locale) {
//     import(
//       /* webpackChunkName: "dayjs.locale." */ `dayjs/locale/${locale}.js`
//     ).then(() => {
//       dayjs.locale(locale);
//     });
//   }
// };

// /**
//  * 初始化 i18next 实例
//  */
// i18n
//   // load translation using http -> see /public/locales (i.e. https://github.com/i18next/react-i18next/tree/master/example/react/public/locales)
//   // learn more: https://github.com/i18next/i18next-http-backend
//   // .use(Backend) // 不适用, 因为我们多语言需要重写
//   // detect user language
//   // learn more: https://github.com/i18next/i18next-browser-languageDetector
//   // .use(LanguageDetector)
//   // pass the i18n instance to react-i18next.
//   .use(initReactI18next)
//   // init i18next
//   // for all options read: https://www.i18next.com/overview/configuration-options
//   .init(
//     {
//       lng: finalLanguage,
//       fallbackLng: finalLanguage, // use en-US if detected lng is not available
//       load: 'currentOnly',
//       ns: [defaultNameSpace],
//       defaultNS: defaultNameSpace,
//       debug: process.env.NODE_ENV === 'development',
//       keySeparator: false,
//       interpolation: {
//         escapeValue: false, // react already safes from xss
//       },
//       resources: {
//         [finalLanguage]: {},
//       },
//       react: {
//         useSuspense: true,
//       },
//       supportedLngs,
//     },
//     () => {
//       if (finalLanguage) {
//         setI18nLanguage(finalLanguage);
//         setDayjsLanguage(finalLanguage);
//       }
//     },
//   );
// // i18n.changeLanguage(currentLanguage)
// i18n.on('languageChanged', (language: string) => {
//   setI18nLanguage(language);
//   setDayjsLanguage(language);
// });

// // 重新设置语言, 使语言立即生效
// i18n.store.on('added', (language: string) => {
//   i18n.changeLanguage(language);
// });

// export default i18n;

import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import Backend from 'i18next-http-backend';
import LanguageDetector from 'i18next-browser-languagedetector';
import { getQueryString } from '@shared';
import zhCN from './locales/zh-CN.json';
import en from './locales/en-US.json';
import gb from './locales/en-GB.json';
import es from './locales/es-ES.json';
import de from './locales/de-DE.json';
import ja from './locales/ja-JP.json';
import fr from './locales/fr-FR.json';
import th from './locales/th-TH.json';
import id from './locales/in-ID.json';
import it from './locales/it-IT.json';
import { initI18n } from './constant/localeData';

const resources = {
  'en-US': {
    translation: en,
  },
  'en-GB': {
    translation: gb,
  },
  'es-ES': {
    translation: es,
  },
  'zh-CN': {
    translation: zhCN,
  },
  'ja-JP': {
    translation: ja,
  },
  'de-DE': {
    translation: de,
  },
  'fr-FR': {
    translation: fr,
  },
  'th-TH': {
    translation: th,
  },
  'in-ID': {
    translation: id,
  },
  'it-IT': {
    translation: it,
  },
} as const;

i18n
  .use(Backend)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init(
    {
      lng: localStorage.getItem('locale') || 'en-US',
      interpolation: {
        escapeValue: false, // not needed for react as it escapes by default
      },
      resources,
    },
    () => {
      const queryLocale = getQueryString('language') || '';
      const currentLang = localStorage.getItem('locale');
      if (queryLocale !== currentLang && initI18n.includes(queryLocale)) {
        i18n.changeLanguage(queryLocale);
      }
    },
  );

export { resources };
export default i18n;
