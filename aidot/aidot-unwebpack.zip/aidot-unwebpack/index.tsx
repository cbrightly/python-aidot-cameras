/*
 * @Author: chenchaoqiang@leedarson.com
 * @Date: 2022-08-08 14:23:26
 * Copyright 2022 Leedarson, All Rights Reserved.
 */
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { setLocalReferrer } from './shared/referrerBuried';
import loggerOperator from './logger/loggerOperator';
import './shared/global';

window.addEventListener('DOMContentLoaded', () => {
  setLocalReferrer();
});

loggerOperator.init();

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement,
);

root.render(
  // <React.StrictMode>
  <BrowserRouter basename={process.env.REACT_APP_ROUTE_BASE_NAME}>
    <App />
  </BrowserRouter>,
  // </React.StrictMode>,
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
