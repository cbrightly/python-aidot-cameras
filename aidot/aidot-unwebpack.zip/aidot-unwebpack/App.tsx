/*
 * @Author: chenchaoqiang@leedarson.com
 * @Date: 2022-08-02 17:27:05
 * Copyright 2022 Leedarson, All Rights Reserved.
 */
import React from 'react';
import RenderRoute from '@router';
import './i18n';
// import './global.less';
window.onerror = (...args) => {
  console.log('error', args);
};
function App() {
  return <RenderRoute />;
}

export default App;
